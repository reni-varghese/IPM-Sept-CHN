package org.reni.controllers;

import java.awt.SecondaryLoop;

import org.reni.clients.FirstClient;
import org.reni.clients.SecondClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ClientController {
	@Autowired
	private FirstClient firstClient;
	@Autowired
	private SecondClient secondClient;
	
	@GetMapping("/messages")
	public String getMessages() {
		String first=firstClient.firstMessage();
		
		String second=secondClient.secondMessage();
		
		return first+"****************"+second;
	}
	

}
