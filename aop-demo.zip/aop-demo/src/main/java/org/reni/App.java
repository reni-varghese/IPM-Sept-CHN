package org.reni;

import org.reni.aspects.LoggingAspect;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        ApplicationContext context=
        		new ClassPathXmlApplicationContext("spring.xml");
        
        GreetApp bean = (GreetApp) context.getBean("greetApp");
        
        	
        bean.welcome();
//        bean.sayHello();
        
//        Sample s=(Sample) context.getBean("sample");
       
    }
}
