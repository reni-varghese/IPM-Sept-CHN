package org.reni;

import org.springframework.stereotype.Component;

@Component
public class Sample {

	public void print(String name) {
		System.out.println("Hello "+name);
	}
}
