package org.reni;

import org.springframework.stereotype.Component;

@Component
public class GreetApp {

	public void sayHello() {
		
		System.out.println("Welcome to AOP");
//		throw new RuntimeException("Error");
		
		
	}
	
	public void welcome() {
		System.out.println("Welcome");
	}
}
