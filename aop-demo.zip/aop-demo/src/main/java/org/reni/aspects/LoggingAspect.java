package org.reni.aspects;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class LoggingAspect {

//	@Before("execution(* org.reni.GreetApp.*(..))")
//	public void beforeLoggingAdvice() {
//		System.out.println("Method started execution");
////	}
//	@Before("within(org.reni.GreetApp)")
//	public void before() {
//		System.out.println("Exection with within");
//	}
//	
	@AfterThrowing("execution(public void sayHello())")
	public void afterAdvice() {
		
		System.out.println("Method completed Successfully");
		
	}
	@Around("execution(public void welcome())")
	public void around(ProceedingJoinPoint joinPoint) {
		
		System.out.println("Welcome method exection started");
		long start=System.currentTimeMillis();
		try {
			joinPoint.proceed();
		} catch (Throwable e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		long end=System.currentTimeMillis();
		long timeTaken=end-start;
		System.out.println(timeTaken);
		
		System.out.println("Welcome method execution completed");
		
	}
}
