package org.reni.controller;

import java.beans.PropertyEditorSupport;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import org.reni.entities.Employee;
import org.reni.service.EmployeeService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import jakarta.annotation.PostConstruct;



@Controller
public class EmployeeController {
	
	
	private EmployeeService employeeService;

	public EmployeeController(EmployeeService employeeService) {
		super();
		this.employeeService = employeeService;
	}
	@InitBinder
	public void initBinder(WebDataBinder binder) {
		binder.registerCustomEditor(LocalDate.class, new PropertyEditorSupport() {

			@Override
			public void setAsText(String text) throws IllegalArgumentException {
				setValue(LocalDate.parse(text,DateTimeFormatter.ofPattern("yyyy-MM-dd")));
			}
			
			
		});
	}
	
//	@GetMapping("/")
//	public String hello() {
//		
//		return "hello";
//	}
	@GetMapping("/")
	public String getAll(Model model) {
		
		var employees=employeeService.getAlEmployees();
		model.addAttribute("emp",employees);
		return "index";
	}
	@GetMapping("/add")
	public String showAdd(Model model) {
		
		Employee employee=new Employee();
		
		model.addAttribute("employee",employee);
		
		return "add";
	}
	@PostMapping("/add-employee")
	public String addEmployee(@ModelAttribute Employee employee) {
		
		var emp=employeeService.addEmployee(employee);
		
		return "redirect:/";
		
	}
	@GetMapping("/edit")
	public String editEmployee(@RequestParam int id,Model model) {
		
		var employee=employeeService.getById(id);
		model.addAttribute("employee", employee);
		return "update";
	}
	@PostMapping("/update-employee")
	public String updateEmployee(@ModelAttribute Employee employee) {
		
		employeeService.updateEmployee(employee);
		return "redirect:/";
	}
	@GetMapping("/delete")
	public String deleteEmployee(@RequestParam int id) {
		
		employeeService.deleteEmployee(id);
		return "redirect:/";
	}

}
