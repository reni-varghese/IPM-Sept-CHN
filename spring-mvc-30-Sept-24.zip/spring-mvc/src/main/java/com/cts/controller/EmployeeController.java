package com.cts.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cts.model.Employee;
import com.cts.service.EmployeeService;

import jakarta.validation.Valid;

import org.springframework.web.bind.annotation.RequestParam;


@Controller

public class EmployeeController {
	@Autowired	
	private EmployeeService employeeService;
	
	@GetMapping("/hello")
	public String sayHello() {
		
		return "hello";
	}
	@GetMapping("/")
	public ModelAndView getAll() {
		
		ModelAndView mv=new ModelAndView("index");
		List<Employee> employees=employeeService.getAll();
		mv.addObject("employees", employees);
		return mv;
	}
	
	@GetMapping("/add")
	public String showAdd(Model model) {
		
		Employee employee=new Employee();
		model.addAttribute("employee", employee);
		
		
		return  "add";
	}
	
	@PostMapping("/add-employee")
	public String addEmployee(@Valid @ModelAttribute Employee employee,BindingResult result) {
		
		if(result.hasErrors()) {
			return "add";
		}
		
		String res=employeeService.addEmployee(employee);
		
		return "redirect:/";
		
	}
	@GetMapping("/update")
	
	public String showUpdate(@RequestParam("id") int id,Model model) {
	
		Employee emp=employeeService.getById(id);
		model.addAttribute("employee",emp);
		
		
		
		
		return "update";
	}
	@PostMapping("/update-employee")
	public String updateEmployee(@Valid @ModelAttribute Employee employee,BindingResult result) {
		
		if(result.hasErrors()) {
			return "update";
		}
		
		String res=employeeService.updateEmployee(employee);
		
		return "redirect:/";
				
		
	}
	@GetMapping("/delete")
	public String deleteEmployee(@RequestParam("id") int id) {
		
		employeeService.deleteEmployee(id);
		return "redirect:/";
	}
	
}
