package com.cts.repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.cts.model.Employee;
@Repository
public class EmployeeRepositoryImpl implements EmployeeRepository {
//	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	
//	@Autowired
	public EmployeeRepositoryImpl(JdbcTemplate jdbcTemplate) {
	super();
	this.jdbcTemplate = jdbcTemplate;
}

	@Override
	public List<Employee> getAll() {
	
		return jdbcTemplate.query("SELECT * FROM employee", new RowMapper<Employee>() {

			@Override
			public Employee mapRow(ResultSet rs, int rowNum) throws SQLException {
				Employee employee=new Employee();
				employee.setId(rs.getInt("id"));
				employee.setName(rs.getString("name"));
				employee.setGender(rs.getString("gender"));
				employee.setAge(rs.getInt("age"));
				employee.setSalary(rs.getDouble("salary"));
				
				return employee;
			}
			
		});
	}

	@Override
	public Employee getById(int id) {
		// TODO Auto-generated method stub
		return jdbcTemplate.queryForObject("SELECT * FROM employee WHERE id=?", new RowMapper<Employee>() {

			@Override
			public Employee mapRow(ResultSet rs, int rowNum) throws SQLException {
				// TODO Auto-generated method stub
				Employee employee=new Employee();
				employee.setId(rs.getInt(1));
				employee.setName(rs.getString(2));
				employee.setGender(rs.getString(3));
				employee.setAge(rs.getInt(4));
				employee.setSalary(rs.getDouble(5));
				return employee;
				
			}
			
			
		},id);
	}

	@Override
	public String addEmployee(Employee employee) {
		jdbcTemplate.update("INSERT INTO employee VALUES(?,?,?,?,?)", employee.getId()
				,employee.getName(),employee.getGender(),employee.getAge(),employee.getSalary());
		return "Employee Saved successfully";
	}

	@Override
	public String updateEmployee(Employee employee) {
		jdbcTemplate.update("UPDATE employee SET name=?,gender=?,age=?,salary=? WHERE id=?",
				employee.getName(),employee.getGender(),employee.getAge(),employee.getSalary(),
				employee.getId());
		return "Employee updated successfully";
	}

	@Override
	public String deleteEmployee(int id) {
		jdbcTemplate.update("DELETE FROM employee WHERE id=?",id);
		return "Employee Deleted successully";
	}

}
