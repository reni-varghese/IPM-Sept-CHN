package com.cts.model;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
public class Employee {
	
	private int id;
	@NotNull
	@Pattern(regexp = "[A-Za-z\s]{3,}",message = "Name should contain only alphabets and min of characters")	
	private String name;
	private String gender;
	@Min(value = 18,message = "Age should be between 18 and 60")
	@Max(value=60,message = "Age should be between 18 and 60")
	private int age;
	private double salary;

}
