package com.recipe.entities;

import java.util.List;

import jakarta.persistence.ElementCollection;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
/**
 * Recipe is an entity class that represents a recipe in the database.
 * It contains details such as the recipe's name, ingredients, instructions, preparation time, and servings.
 */
@Entity // Defines that this class can be mapped to a table
@Table(name="RecipeMenu") // Specifies the table name in the database
public class Recipe {
	@Id // Marks this field as the primary key
    @GeneratedValue(strategy = GenerationType.IDENTITY) // Specifies the generation strategy for the primary key
    private int id;
    private String name;
    
    @ElementCollection // Specifies that this field is a collection of elements
    private List<String> ingredients;
    private String instructions;
    private int prep_time;
    private int servings;

    /**
     * Gets the recipe ID.
     * @return the recipe ID
     */
    public int getId() {
        return id;
    }

    /**
     * Sets the recipe ID.
     * @param id the recipe ID to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Gets the recipe name.
     * @return the recipe name
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the recipe name.
     * @param name the recipe name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Gets the list of ingredients.
     * @return the list of ingredients
     */
    public List<String> getIngredients() {
        return ingredients;
    }

    /**
     * Sets the list of ingredients.
     * @param ingredients the list of ingredients to set
     */
    public void setIngredients(List<String> ingredients) {
        this.ingredients = ingredients;
    }

    /**
     * Gets the cooking instructions.
     * @return the cooking instructions
     */
    public String getInstructions() {
        return instructions;
    }

    /**
     * Sets the cooking instructions.
     * @param instructions the cooking instructions to set
     */
    public void setInstructions(String instructions) {
        this.instructions = instructions;
    }

    /**
     * Gets the preparation time.
     * @return the preparation time in minutes
     */
    public int getPrep_time() {
        return prep_time;
    }

    /**
     * Sets the preparation time.
     * @param prep_time the preparation time to set
     */
    public void setPrep_time(int prep_time) {
        this.prep_time = prep_time;
    }

    /**
     * Gets the number of servings.
     * @return the number of servings
     */
    public int getServings() {
        return servings;
    }

    /**
     * Sets the number of servings.
     * @param servings the number of servings to set
     */
    public void setServings(int servings) {
        this.servings = servings;
    }

    /**
     * Constructs a Recipe with the specified details.
     * @param id the recipe ID
     * @param name the recipe name
     * @param ingredients the list of ingredients
     * @param instructions the cooking instructions
     * @param prep_time the preparation time in minutes
     * @param servings the number of servings
     */
    public Recipe(int id, String name, List<String> ingredients, String instructions, int prep_time, int servings) {
        super();
        this.id = id;
        this.name = name;
        this.ingredients = ingredients;
        this.instructions = instructions;
        this.prep_time = prep_time;
        this.servings = servings;
    }

    /**
     * Default constructor.
     */
    public Recipe() {
        super();
        // TODO Auto-generated constructor stub
    }

    /**
     * Returns a string representation of the Recipe.
     * @return a string representation of the Recipe
     */
    @Override
    public String toString() {
        return "Recipe [id=" + id + ", name=" + name + ", ingredients=" + ingredients + ", instructions=" + instructions
                + ", prep_time=" + prep_time + ", servings=" + servings + "]";
    }

}
