package com.recipe.service;

import java.util.List;

import com.recipe.entities.Recipe;
/**
* RecipeService is an interface that defines operations for managing recipes.
* It provides methods to get all recipes, get a recipe by ID, add a new recipe, and delete a recipe.
*/
public interface RecipeService {
	/**
     * Retrieves all recipes.
     * @return a list of all recipes
     */
    List<Recipe> getAllRecipes();

    /**
     * Retrieves a recipe by its ID.
     * @param id the ID of the recipe to retrieve
     * @return the recipe with the specified ID
     */
    Recipe getById(int id);

    /**
     * Adds a new recipe.
     * @param recipe the recipe to add
     * @return the added recipe
     */
    Recipe addRecipe(Recipe recipe);

    // Uncomment the following method to update a recipe
    /*
    Recipe updateRecipe(int id, Recipe recipe);
    */

    /**
     * Deletes a recipe by its ID.
     * @param id the ID of the recipe to delete
     * @return a message indicating the result of the deletion
     */
    String deletRecipe(int id);

}
