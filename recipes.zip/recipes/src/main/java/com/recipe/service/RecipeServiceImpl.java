package com.recipe.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.recipe.entities.Recipe;
import com.recipe.exceptions.RecipeNotFoundException;
import com.recipe.repository.RecipeRepository;
/**
 * RecipeServiceImpl is a service class that implements the RecipeService interface.
 * It handles the business logic for managing recipes.
 */
@Service
public class RecipeServiceImpl implements RecipeService {

    private RecipeRepository recipeRepository;

    /**
     * Constructs a RecipeServiceImpl with the specified RecipeRepository.
     * @param recipeRepository the recipe repository
     */
    public RecipeServiceImpl(RecipeRepository recipeRepository) {
        super();
        this.recipeRepository = recipeRepository;
    }

    /**
     * Retrieves all recipes.
     * @return a list of all recipes
     */
    @Override
    public List<Recipe> getAllRecipes() {
        return recipeRepository.findAll();
    }

    /**
     * Retrieves a recipe by its ID.
     * @param id the ID of the recipe to retrieve
     * @return the recipe with the specified ID
     * @throws RecipeNotFoundException if the recipe is not found
     */
    @Override
    public Recipe getById(int id) {
        return recipeRepository.findById(id)
                .orElseThrow(() -> new RecipeNotFoundException("Recipe with Id " + id + " does not exist"));
    }

    /**
     * Adds a new recipe.
     * @param recipe the recipe to add
     * @return the added recipe
     */
    @Override
    public Recipe addRecipe(Recipe recipe) {
        return recipeRepository.save(recipe);
    }

    // Uncomment the following method to update a recipe
    /*
    @Override
    public Recipe updateRecipe(int id, Recipe recipe) {
        Optional<Recipe> byId = recipeRepository.findById(id);
        if (!byId.isPresent()) {
            throw new RecipeNotFoundException("Recipe with Id " + id + " does not exist");
        }
        Recipe recp = byId.get();
        if (recipe.getName() != null) {
            recp.setName(recipe.getName());
        }
        if (recipe.getIngredients() != null) {
            recp.setIngredients(recipe.getIngredients());
        }
        if (recipe.getInstructions() != null) {
            recp.setInstructions(recipe.getInstructions());
        }
        if (recipe.getPrep_time() != 0) {
            recp.setPrep_time(recipe.getPrep_time());
        }
        if (recipe.getServings() != 0) {
            recp.setServings(recipe.getServings());
        }
        return recipeRepository.save(recp);
    }
    */

    /**
     * Deletes a recipe by its ID.
     * @param id the ID of the recipe to delete
     * @return a message indicating the result of the deletion
     * @throws RecipeNotFoundException if the recipe is not found
     */
    @Override
    public String deletRecipe(int id) {
        Optional<Recipe> optRecp = recipeRepository.findById(id);
        if (optRecp.isEmpty()) {
            throw new RecipeNotFoundException("Recipe with Id " + id + " does not exist");
        }
        recipeRepository.deleteById(id);
        return "Recipe with Id " + id + " deleted successfully";
    }

}
