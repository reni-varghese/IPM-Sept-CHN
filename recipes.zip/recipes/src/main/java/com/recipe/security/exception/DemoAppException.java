package com.recipe.security.exception;

import org.springframework.http.HttpStatus;
/**
 * DemoAppException is a custom exception that extends RuntimeException.
 * It is used to handle application-specific exceptions with an HTTP status and a message.
 */
public class DemoAppException extends RuntimeException {
	/**
     * Constructs a DemoAppException with the specified HTTP status and detail message.
     * @param status the HTTP status
     * @param message the detail message
     */
    public DemoAppException(HttpStatus status, String message) {
        super(message);
    }

}
