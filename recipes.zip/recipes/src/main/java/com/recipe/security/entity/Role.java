package com.recipe.security.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
/**
 * Role is an entity class that represents a user role in the database.
 * It contains details such as the role's ID and name.
 */
@Entity
public class Role {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column(nullable = false, unique = true)
    private String name;

    /**
     * Gets the role ID.
     * @return the role ID
     */
    public int getId() {
        return id;
    }

    /**
     * Sets the role ID.
     * @param id the role ID to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Gets the role name.
     * @return the role name
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the role name.
     * @param name the role name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Constructs a Role with the specified ID and name.
     * @param id the role ID
     * @param name the role name
     */
    public Role(int id, String name) {
        super();
        this.id = id;
        this.name = name;
    }

    /**
     * Default constructor.
     */
    public Role() {
        super();
        // TODO Auto-generated constructor stub
    }

    /**
     * Returns a string representation of the Role.
     * @return a string representation of the Role
     */
    @Override
    public String toString() {
        return "Role [id=" + id + ", name=" + name + "]";
    }

}
