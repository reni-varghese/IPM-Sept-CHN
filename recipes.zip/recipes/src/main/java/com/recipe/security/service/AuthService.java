package com.recipe.security.service;

import com.recipe.dtos.LoginDto;
/**
 * AuthService is an interface that defines authentication-related operations.
 * It provides a method for user login.
 */
public interface AuthService {
	/**
     * Authenticates a user based on the provided login credentials.
     * @param loginDto the login credentials
     * @return a JWT token if authentication is successful
     */
    public String login(LoginDto loginDto);

}
