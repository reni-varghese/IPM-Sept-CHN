package com.recipe.security.service;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import com.recipe.dtos.LoginDto;
import com.recipe.security.JwtAuthenticationProvider;

/**
 * AuthServiceImpl is a service class that implements the AuthService interface.
 * It handles user authentication and JWT token generation.
 */
@Service
public class AuthServiceImpl implements AuthService {

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private JwtAuthenticationProvider jwTokenProvider;

    /**
     * Authenticates a user based on the provided login credentials and generates a JWT token.
     * @param loginDto the login credentials
     * @return a JWT token if authentication is successful
     */
    @Override
    public String login(LoginDto loginDto) {
        UsernamePasswordAuthenticationToken token = 
                new UsernamePasswordAuthenticationToken(loginDto.getUsernameOrEmail(), loginDto.getPassword());

        Authentication authenticate = authenticationManager.authenticate(token);

        SecurityContextHolder.getContext().setAuthentication(authenticate);

        String jwtToken = jwTokenProvider.generateToken(authenticate);

        return jwtToken;
    }

}
