package com.recipe.security.userrepository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.recipe.security.entity.User;
/**
 * UserRepository is a repository interface for managing User entities.
 * It extends JpaRepository to provide CRUD operations and additional JPA functionalities.
 */
public interface UserRepository extends JpaRepository<User, Integer>  {
	/**
     * Finds a user by their username or email.
     * @param username the username
     * @param email the email
     * @return an Optional containing the found user, or an empty Optional if no user is found
     */
    Optional<User> findByUsernameOrEmail(String username, String email);

}
