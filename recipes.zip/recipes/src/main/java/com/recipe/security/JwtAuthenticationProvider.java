package com.recipe.security;

import java.security.Key;
import java.util.Date;

import javax.crypto.SecretKey;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Component;

import com.recipe.security.exception.DemoAppException;

import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.MalformedJwtException;
import io.jsonwebtoken.UnsupportedJwtException;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;


@Component
public class JwtAuthenticationProvider {
	 @Value("${app.jwt.secret}")
	    private String jwtSecret;

	    @Value("${app.jwt.expiry-mills}")
	    private long expiryMills;

	    /**
	     * Generates a JWT token for the authenticated user.
	     * @param authentication the authentication object containing user details
	     * @return the generated JWT token
	     */
	    public String generateToken(Authentication authentication) {
	        String username = authentication.getName();
	        System.out.println(username+"--------------------------------");

	        Date currentDate = new Date();
	        Date expiryDate = new Date(currentDate.getTime() + expiryMills);

	        String token = Jwts.builder()
	                .subject(username)
	                .issuedAt(currentDate)
	                .expiration(expiryDate)
	                .signWith(key())
	                .compact();

	        return token;
	    }

	    /**
	     * Creates a Key object from the JWT secret.
	     * @return the Key object
	     */
	    private Key key() {
	        return Keys.hmacShaKeyFor(Decoders.BASE64.decode(jwtSecret));
	    }

	    /**
	     * Extracts the username from the JWT token.
	     * @param token the JWT token
	     * @return the username extracted from the token
	     */
	    public String getUserNameFromToken(String token) {
	        String username = Jwts.parser()
	                .verifyWith((SecretKey) key())
	                .build()
	                .parseSignedClaims(token)
	                .getPayload()
	                .getSubject();

	        return username;
	    }

	    /**
	     * Validates the JWT token.
	     * @param token the JWT token to validate
	     * @return true if the token is valid, false otherwise
	     * @throws DemoAppException if the token is invalid, expired, unsupported, or empty
	     */
	    public boolean validateToken(String token) {
	        try {
	            Jwts.parser()
	                .verifyWith((SecretKey) key())
	                .build()
	                .parse(token);

	            return true;
	        } catch (MalformedJwtException ex) {
	            throw new DemoAppException(HttpStatus.BAD_REQUEST, "Invalid Token");
	        } catch (ExpiredJwtException ex) {
	            throw new DemoAppException(HttpStatus.BAD_REQUEST, "Token is expired");
	        } catch (UnsupportedJwtException ex) {
	            throw new DemoAppException(HttpStatus.BAD_REQUEST, "Unsupported Exception");
	        } catch (IllegalArgumentException ex) {
	            throw new DemoAppException(HttpStatus.BAD_REQUEST, "Token claims are empty");
	        }
	    }

}
