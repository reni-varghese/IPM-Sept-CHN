package com.recipe.security.service;

import java.util.Collections;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;

import com.recipe.security.entity.User;
import com.recipe.security.userrepository.UserRepository;
/**
 * CustomUserDetailService is a service class that implements the UserDetailsService interface.
 * It loads user-specific data during authentication.
 */
@Component
public class CustomUserDetailService implements UserDetailsService {
	 @Autowired
	    private UserRepository userRepository;

	    

	    /**
	     * Loads the user details by username or email.
	     * @param username the username or email
	     * @return the UserDetails object
	     * @throws UsernameNotFoundException if the user is not found
	     */
	    @Override
	    public UserDetails loadUserByUsername(String username) {
	        User user = userRepository.findByUsernameOrEmail(username, username)
	                .orElseThrow(() -> new UsernameNotFoundException("User with username " + username + " not found."));
	        System.out.println(user+"===================");
	        SimpleGrantedAuthority authority = new SimpleGrantedAuthority(user.getRole());
	        Set<SimpleGrantedAuthority> authorities = Collections.singleton(authority);
	        System.out.println(authorities);
	        return new org.springframework.security.core.userdetails.User(user.getUsername(),
	                user.getPassword(), authorities);
	    }

	    /**
	     * Provides the AuthenticationManager bean.
	     * @param config the AuthenticationConfiguration
	     * @return the AuthenticationManager
	     * @throws Exception if an error occurs while getting the AuthenticationManager
	     */
	    @Bean
	    AuthenticationManager authenticationManager(AuthenticationConfiguration config) throws Exception {
	        return config.getAuthenticationManager();
	    }

}
