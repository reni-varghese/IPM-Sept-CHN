package com.recipe.security;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.filter.OncePerRequestFilter;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * JwtAuthenticationFilter is a filter that intercepts HTTP requests to validate
 * JWT tokens. It extends OncePerRequestFilter to ensure it is executed once per
 * request.
 */
@Component
public class JwtAuthenticationFilter extends OncePerRequestFilter {
	@Autowired
	private JwtAuthenticationProvider jwTokenProvider;

	@Autowired
	private UserDetailsService userDetailsService;

	/**
	 * Filters incoming requests to validate JWT tokens and set the authentication
	 * context.
	 * 
	 * @param request     the HttpServletRequest
	 * @param response    the HttpServletResponse
	 * @param filterChain the FilterChain
	 * @throws ServletException if a servlet error occurs
	 * @throws IOException      if an input or output error occurs
	 */
	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
			throws ServletException, IOException {
		String jwtToken = getTokenFromRequest(request);
		System.out.println(jwtToken+"++++++++++++++++++++++++++");

		if (StringUtils.hasText(jwtToken) && jwTokenProvider.validateToken(jwtToken)) {
			String username = jwTokenProvider.getUserNameFromToken(jwtToken);
			System.out.println("-----------------"+username);

			// Load the username from the UserDetailsService
			UserDetails userDetails = userDetailsService.loadUserByUsername(username);

			UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(userDetails,
					null, userDetails.getAuthorities());

			authentication.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));

			SecurityContextHolder.getContext().setAuthentication(authentication);
		}
		filterChain.doFilter(request, response);
	}

	/**
	 * Extracts the JWT token from the request header.
	 * 
	 * @param request the HttpServletRequest
	 * @return the JWT token, or null if not present
	 */
	private String getTokenFromRequest(HttpServletRequest request) {
		String bearerToken = request.getHeader("Authorization");

		// Bearer dgsfasfdassafsa.9088f908099asda.fasafasfasdfdf
		if (StringUtils.hasText(bearerToken) && bearerToken.startsWith("Bearer")) {
			System.out.println(bearerToken);
			return bearerToken.substring(7);
		}
		return null;
	}

}
