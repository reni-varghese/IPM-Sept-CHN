package com.recipe.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.recipe.entities.Recipe;
/**
 * RecipeRepository is a repository interface for managing Recipe entities.
 * It extends JpaRepository to provide CRUD operations and additional JPA functionalities.
 */

public interface RecipeRepository extends JpaRepository<Recipe, Integer> {

}
