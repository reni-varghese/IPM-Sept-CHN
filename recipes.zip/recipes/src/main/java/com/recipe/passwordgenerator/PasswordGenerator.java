package com.recipe.passwordgenerator;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
/**
 * PasswordGenerator is a utility class that generates a hashed password using BCrypt.
 */
public class PasswordGenerator {

    /**
     * The main method that generates and prints a hashed password.
     * @param args command-line arguments (not used)
     */
    public static void main(String[] args) {

        PasswordEncoder encoder = new BCryptPasswordEncoder();

        // Generates and prints the hashed password
        System.out.println(encoder.encode("pass"));
    }

}
