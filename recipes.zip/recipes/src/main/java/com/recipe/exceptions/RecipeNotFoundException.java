package com.recipe.exceptions;
/**
 * RecipeNotFoundException is a custom exception that is thrown when a requested recipe is not found.
 * It extends the RuntimeException class.
 */
public class RecipeNotFoundException extends RuntimeException {
	/**
     * Default constructor.
     */
    public RecipeNotFoundException() {
        super();
        // TODO Auto-generated constructor stub
    }

    /**
     * Constructs a RecipeNotFoundException with the specified detail message.
     * @param message the detail message
     */
    public RecipeNotFoundException(String message) {
        super(message);
        // TODO Auto-generated constructor stub
    }

}
