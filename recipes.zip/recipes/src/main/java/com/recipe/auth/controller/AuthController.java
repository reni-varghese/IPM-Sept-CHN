package com.recipe.auth.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.recipe.dtos.JwtAuthResponse;
import com.recipe.dtos.LoginDto;
import com.recipe.security.service.AuthService;



@RestController
public class AuthController {
	@Autowired //used for automatic dependency injection
	private AuthService authService;
	/**
	 *  Handles HTTP POST requests for user login.
	 * @param  the login data transfer object containing user credentials.
	 * @return ResponseEntity containing the JWT authentication response with the access
	 */

	@PostMapping("/login")  //maps HTTP POST requests to specific handler//shortcut for the @RequestMapping(method = requestMethod.POST)
	public ResponseEntity<JwtAuthResponse> login(@RequestBody LoginDto loginDto) {  //Spring Boot automatically converts the request body into the specified java object
      /**
       * Authenticate the user and generate a JWT token.
       */
		String login = authService.login(loginDto);
		
		/**
		 * Create a response object containing the JWT token.
		 */
		JwtAuthResponse jwtAuthResponse = new JwtAuthResponse();
		jwtAuthResponse.setAccessToken(login);
         /**
          * Return the response entity with the JWT token.
          */
		return ResponseEntity.ok(jwtAuthResponse);

	}

}
