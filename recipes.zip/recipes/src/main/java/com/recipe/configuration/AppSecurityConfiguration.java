package com.recipe.configuration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import com.recipe.security.JwtAuthenticationEntryPoint;
import com.recipe.security.JwtAuthenticationFilter;

import jakarta.servlet.Filter;


@Configuration
@EnableMethodSecurity
public class AppSecurityConfiguration {
	// Enables method-level security.

		@Autowired
		private JwtAuthenticationEntryPoint entryPoint;
		/**
		 * Constructor for AppSecurityConfig.
		 * 
		 * @param entryPoint the entry point for handling unauthorized access.
		 * @param filter     the JWT authentication filter.
		 */

		@Autowired
		private JwtAuthenticationFilter filter;

		/**
		 * Configures the security filter chain.
		 * 
		 * @param the HttpSecurity object to configure.
		 * @return the configured SecurityFilterChain.
		 * @throws Exception if an error occurs during configuration.
		 */

		@Bean
		public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
			http.csrf(config -> config.disable());
			http.authorizeHttpRequests(
					auth -> auth.requestMatchers("/login").permitAll().anyRequest().authenticated())
					.sessionManagement(smc -> smc.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
					.exceptionHandling(ehc -> ehc.authenticationEntryPoint(entryPoint))
					.addFilterBefore(filter, UsernamePasswordAuthenticationFilter.class);
			return http.build();
		}

		/**
		 * Provides a PasswordEncoder bean.
		 * 
		 * @return a BCryptPasswordEncoder instance.
		 */

		@Bean
		PasswordEncoder passwordEncoder() {
			return new BCryptPasswordEncoder();
		}

}
