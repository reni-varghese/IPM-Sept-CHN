package com.recipe.dtos;

public class LoginDto {
	private String usernameOrEmail;
	private String password;
	/**
     * Gets the username or email.
     * @return the username or email
     */

	public String getUsernameOrEmail() {
		return usernameOrEmail;
	}

    /**
     * Sets the username or email.
     * @param usernameOrEmail the username or email to set
     */
	

	public void setUsernameOrEmail(String usernameOrEmail) {
		this.usernameOrEmail = usernameOrEmail;
	}
	/**
     * Gets the password.
     * @return the password
     */

	public String getPassword() {
		return password;
	}
	/**
     * Sets the password.
     * @param password the password to set
     */

	public void setPassword(String password) {
		this.password = password;
	}
	/**
     * Constructs a LoginDto with the specified username or email and password.
     * @param usernameOrEmail the username or email
     * @param password the password
     */

	public LoginDto(String usernameOrEmail, String password) {
		super();
		this.usernameOrEmail = usernameOrEmail;
		this.password = password;
	}
	/**
     * Default constructor.
     */

	public LoginDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	/**
     * Returns a string representation of the LoginDto.
     * @return a string representation of the LoginDto
     */

	@Override
	public String toString() {
		return "LoginDto [usernameOrEmail=" + usernameOrEmail + ", password=" + password + "]";
	}


}
