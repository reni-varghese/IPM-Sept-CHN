package com.recipe.dtos;

public class JwtAuthResponse {
	private String accessToken;

	private String tokenType = "Bearer";

	/**
	 * Gets the access token.
	 * 
	 * @return the access token
	 */

	public String getAccessToken() {
		return accessToken;
	}

	/**
	 * Sets the access token.
	 * 
	 * @param accessToken the access token to set
	 */

	public void setAccessToken(String accessToken) {
		this.accessToken = accessToken;
	}

	/**
	 * Gets the token type.
	 * 
	 * @return the token type
	 */

	public String getTokenType() {
		return tokenType;
	}

	/**
	 * Sets the token type.
	 * 
	 * @param tokenType the token type to set
	 */

	public void setTokenType(String tokenType) {
		this.tokenType = tokenType;
	}

	/**
	 * Constructs a JwtAuthResponse with the specified access token and token type.
	 * 
	 * @param accessToken the access token
	 * @param tokenType   the token type
	 */

	public JwtAuthResponse(String accessToken, String tokenType) {
		super();
		this.accessToken = accessToken;
		this.tokenType = tokenType;
	}

	/**
	 * Default constructor.
	 */

	public JwtAuthResponse() {
		super();
		// TODO Auto-generated constructor stub
	}

}
