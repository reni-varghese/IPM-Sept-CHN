package com.recipe.dtos;

public class UserDto {

	private String name;
	private String username;
	private String email;
	private String password;
	/**
     * Gets the user's name.
     * @return the name
     */

	public String getName() {
		return name;
	}
	/**
     * Sets the user's name.
     * @param name the name to set
     */

	public void setName(String name) {
		this.name = name;
	}
	/**
     * Gets the user's username.
     * @return the username
     */

	public String getUsername() {
		return username;
	}
	 /**
     * Sets the user's username.
     * @param username the username to set
     */

	public void setUsername(String username) {
		this.username = username;
	}

    /**
     * Gets the user's email.
     * @return the email
     */

	public String getEmail() {
		return email;
	}
	 /**
     * Sets the user's email.
     * @param email the email to set
     */

	public void setEmail(String email) {
		this.email = email;
	}
	/**
     * Gets the user's password.
     * @return the password
     */

	public String getPassword() {
		return password;
	}
	/**
     * Sets the user's password.
     * @param password the password to set
     */

	public void setPassword(String password) {
		this.password = password;
	}

    /**
     * Constructs a UserDto with the specified name, username, email, and password.
     * @param name the user's name
     * @param username the user's username
     * @param email the user's email
     * @param password the user's password
     */

	public UserDto(String name, String username, String email, String password) {
		super();
		this.name = name;
		this.username = username;
		this.email = email;
		this.password = password;
	}
	 /**
     * Default constructor.
     */

	public UserDto() {
		super();
		// TODO Auto-generated constructor stub
	}

    /**
     * Returns a string representation of the UserDto.
     * @return a string representation of the UserDto
     */

	@Override
	public String toString() {
		return "UserDto [name=" + name + ", username=" + username + ", email=" + email + ", password=" + password + "]";
	}


}
