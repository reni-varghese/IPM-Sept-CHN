package com.recipe.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.recipe.entities.Recipe;
import com.recipe.service.RecipeService;


@RequestMapping("/receipe")
public class RecipeController {
	private RecipeService recipeService;
	/**
     * Constructor to initialize RecipeService.
     * @param recipeService the service to manage recipes
     */

	public RecipeController(RecipeService recipeService) {
		super();
		this.recipeService = recipeService;
	}

    /**
     * Handles HTTP GET requests to retrieve all recipes.
     * @return a list of all recipes
     */

	@GetMapping // handle the HTTP GET requests
	public List<Recipe> getAll() {
		return recipeService.getAllRecipes();
	}
	/**
     * Handles HTTP POST requests to add a new recipe.
     * @param recipe the recipe to be added
     * @return a ResponseEntity containing the created recipe and HTTP status
     */

	@PostMapping
	public ResponseEntity<Recipe> addRecipe(@RequestBody Recipe recipe) {
		var recp = recipeService.addRecipe(recipe);
		// return new ResponseEntity<Recipe>(recp,HttpStatus.CREATED);
		return ResponseEntity.status(HttpStatus.CREATED).body(recp);
	}
	/**
     * Handles HTTP GET requests to retrieve a recipe by its ID.
     * @param id the ID of the recipe to retrieve
     * @return the recipe with the specified ID
     */

	@GetMapping("/{id}")
	public Recipe getRecipeById(@PathVariable int id) {
		return recipeService.getById(id);
	}

//	@PutMapping("/{id}")
//	public Recipe update(@PathVariable int id,@RequestBody Recipe recipe) {
//		return recipeService.updateRecipe(id, recipe);
//	}
	
	/**
     * Handles HTTP DELETE requests to delete a recipe by its ID.
     * @param id the ID of the recipe to delete
     * @return a ResponseEntity with HTTP status NO_CONTENT
     */
	@DeleteMapping("/{id}")
	public ResponseEntity<String> delete(@PathVariable int id) {
		recipeService.deletRecipe(id);
		return new ResponseEntity<String>(HttpStatus.NO_CONTENT);
	}

}

