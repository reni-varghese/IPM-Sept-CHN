package com.recipe.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.recipe.exceptions.RecipeNotFoundException;

public class ErrorHandler {
	/**
     * Handles RecipeNotFoundException.
     * 
     * @param  the RecipeNotFoundException thrown when a recipe is not found.
     * @return ResponseEntity containing the exception message and HTTP status NOT_FOUND.
     */
	@ExceptionHandler(RecipeNotFoundException.class) // Specifies the exception to handle.
	public ResponseEntity<String> handleRecipeNotFound(RecipeNotFoundException ex){
		String message=ex.getMessage();
		return new ResponseEntity<String>(message, HttpStatus.NOT_FOUND);
	}

}
