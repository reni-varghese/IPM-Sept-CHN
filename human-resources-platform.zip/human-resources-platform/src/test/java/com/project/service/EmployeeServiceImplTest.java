//package com.project.service;
//
//import static org.junit.jupiter.api.Assertions.assertEquals;
//import static org.junit.jupiter.api.Assertions.fail;
//import static org.mockito.ArgumentMatchers.anyInt;
//import static org.mockito.Mockito.mock;
//import static org.mockito.Mockito.when;
//
//import java.util.List;
//import java.util.Optional;
//
//import org.junit.jupiter.api.Disabled;
//import org.junit.jupiter.api.Test;
//import org.springframework.boot.test.context.SpringBootTest;
//
//import com.project.entities.Employee;
//import com.project.repository.EmployeeRepository;
//@SpringBootTest
//class EmployeeServiceImplTest {
//	EmployeeRepository repository=mock(EmployeeRepository.class);
//	EmployeeService service=new EmployeeServiceImpl(repository);
//	@Test
//	void testGetAllEmployees() {
//		when(repository.findAll()).thenReturn(List.of(new Employee(1,"Jyothi",28,"Engineering","Electrical",45000),
//					new Employee(2,"Lalitha",26,"Customs","Income tax", 39000)));
//		
//		var employees=service.getAllEmployees();
//		assertEquals(2, employees.size());
//	}
//
//	@Test
//	@Disabled
//	void testGetById() {
//		when(repository.findById(anyInt())).thenReturn(Optional.of(new Employee(1,"Jyothi",28,"Engineering","Electrical",45000)));
//		Employee e=service.getById(2);
//		assertEquals("Jyothi",e.getName());
//	}
//	
//	
//
//	@Test
//	@Disabled
//	void testAddEmployee() {
//		fail("Not yet implemented");
//	}
//
//	@Test
//	@Disabled
//	void testUpdateEmployee() {
//		fail("Not yet implemented");
//	}
//
//	@Test
//	@Disabled
//	void testDeleteEmployee() {
//		fail("Not yet implemented");
//	}
//
//}
