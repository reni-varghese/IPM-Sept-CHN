package com.project.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.project.entities.Employee;
import com.project.exception.EmployeeNotFoundException;
import com.project.repository.EmployeeRepository;
@Service
public class EmployeeServiceImpl implements EmployeeService {

	public EmployeeRepository employeeRepository;
	
	
	public EmployeeServiceImpl(EmployeeRepository employeeRepository) {
		super();
		this.employeeRepository = employeeRepository;
	}

	@Override
	public List<Employee> getAllEmployees() {
		return employeeRepository.findAll();
	}

	@Override
	public Employee getById(int id) {
		// TODO Auto-generated method stub
		return employeeRepository.findById(id)
				.orElseThrow(()->new EmployeeNotFoundException("Employee with Id " + id + "does not exist"));
	}

	@Override
	public Employee addEmployee(Employee employee) {
		return employeeRepository.save(employee);
	}

	@Override
	public Employee updateEmployee(int id, Employee employee) {
		// TODO Auto-generated method stub
		Optional<Employee> byId = employeeRepository.findById(id);
		if(!byId.isPresent()) {
			throw new EmployeeNotFoundException("Employee with Id"+id+ "does not exist");
		}
		

		//return employeeRepository.save(employee);
		Employee emp=byId.get();
		if(employee.getName()!=null) {
			emp.setName(employee.getName());
		}
		if(employee.getAge()!=0) {
			emp.setAge(employee.getAge());
		}
		if(employee.getDepartment()!=null) {
			emp.setDepartment(employee.getDepartment());
		}
		if(employee.getPosition()!=null) {
			emp.setPosition(employee.getPosition());
		}
		if(employee.getSalary()!=0) {
			emp.setSalary(employee.getSalary());
		}
		return employeeRepository.save(emp);
	}

	@Override
	public String deleteEmployee(int id) {
		// TODO Auto-generated method stub
		Optional<Employee> optEmp=employeeRepository.findById(id);
		if(optEmp.isEmpty()) {
			throw new EmployeeNotFoundException("Employee with Id "+id+" does not exist");
		}
		employeeRepository.deleteById(id);
		return "Employee with Id "+id+" deleted successfully";
	}

}
