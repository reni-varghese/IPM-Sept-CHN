package com.project.service;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.project.entities.Employee;

public interface EmployeeService {
	List<Employee> getAllEmployees();
	Employee getById(int id);
	Employee addEmployee(Employee employee);
	Employee updateEmployee(int id,Employee employee);
	String deleteEmployee(int id);
}
