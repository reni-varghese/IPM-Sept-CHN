package com.project.service;

import com.project.dtos.LoginDto;
import com.project.dtos.UserDto;

public interface AuthService {
	String login(LoginDto loginDto);
	
	String register(UserDto userDto);
}
