package com.project.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import com.project.dtos.LoginDto;
import com.project.dtos.UserDto;
import com.project.security.JwtTokenProvider;
@Service
public class AuthServiceImpl implements AuthService {
	
	@Autowired
	private AuthenticationManager authenticationManager;
	@Autowired
	private JwtTokenProvider jwtTokenProvider;
	
	@Override
	public String login(LoginDto loginDto) {
		System.out.println("AuthService***************************2222222222222");

		UsernamePasswordAuthenticationToken token=
				new UsernamePasswordAuthenticationToken(loginDto.getUsernameOrEmail(), loginDto.getPassword());
		
		Authentication authentication= authenticationManager.authenticate(token);
		
		SecurityContextHolder.getContext().setAuthentication(authentication);
		System.out.println("AuthService***************************");
		
		String jwt=jwtTokenProvider.generateToken(authentication);
		System.out.println(jwt);
		
		return jwt;
	}

	@Override
	public String register(UserDto userDto) {
		// TODO Auto-generated method stub
		return null;
	}

}
