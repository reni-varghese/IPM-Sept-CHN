package com.project.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.project.exception.EmployeeNotFoundException;

@ControllerAdvice
public class ErrorHandler {
	@ExceptionHandler({EmployeeNotFoundException.class})
	public ResponseEntity<String> handleEmployeeNotFound(EmployeeNotFoundException ex){
		String message =ex.getMessage();
		
		return new ResponseEntity<String>(message,HttpStatus.NOT_FOUND);
		
	}
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<String> handleValidationErrors(MethodArgumentNotValidException ex){
		List<ObjectError> errors=ex.getAllErrors();
		String message="";
		for(ObjectError objectError : errors) {
			message+=objectError.getDefaultMessage()+"\n";
		}
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(message);
		
		
	}
	
	
	
	
	
}
