package com.project.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.project.entities.Employee;
import com.project.service.EmployeeService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/employees")
public class EmployeeController {
	private EmployeeService employeeService;
	public EmployeeController(EmployeeService employeeService) {
		super();
		this.employeeService = employeeService;
	}
	@GetMapping
	public List<Employee> getAll(){
		return employeeService.getAllEmployees();
		
	}
	/*@PostMapping
	public  Employee addEmployee(@RequestBody Employee employee){
		return employeeService.addEmployee(employee);
		
	} response 200 ok*/
	
	@PreAuthorize("hasRole('ADMIN')")
	@PostMapping("/add")
	public ResponseEntity<Employee> addEmployee( @Valid @RequestBody Employee employee){
		var emp=employeeService.addEmployee(employee);
		return new ResponseEntity<Employee>(emp,HttpStatus.CREATED);
		// return ResponseEntity.status(HttpStatus.CREATED).body(emp);/*another way for 201 created*/
	}
	
	@GetMapping("/{id}")
	public Employee getEmployeeById(@PathVariable int id) {
		return employeeService.getById(id);
		
	}
	
	@PutMapping("/{id}")
	public Employee update(@PathVariable int id, @Valid @RequestBody Employee employee) {
		return employeeService.updateEmployee(id,employee);
	}
	@DeleteMapping("/{id}")
	public ResponseEntity<String> delete(@PathVariable int id) {
			var delemp = employeeService.deleteEmployee(id);
			return new ResponseEntity<String>(delemp ,HttpStatus.NO_CONTENT);
		
	}
}
