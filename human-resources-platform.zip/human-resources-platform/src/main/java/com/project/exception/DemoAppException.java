package com.project.exception;

import org.springframework.http.HttpStatus;

public class DemoAppException extends RuntimeException{
	public DemoAppException(HttpStatus status,String message) {
		
}
	


}
