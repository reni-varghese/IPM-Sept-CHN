package org.reni;

public class InvalidDenominatorException extends RuntimeException {

	public InvalidDenominatorException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InvalidDenominatorException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
