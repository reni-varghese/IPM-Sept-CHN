package org.reni;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvFileSource;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.ValueSource;

class CalculatorTest {
	Calculator calc;
	@BeforeAll
	static void  beforeAll() {
		System.out.println("Before all");
	}
	@AfterAll
	static void afterAll() {
		System.out.println("After All");
	}
	
	@BeforeEach
	void init() {
		calc=new Calculator();
		
		System.out.println("Before each executed");
	}
	@AfterEach
	void clearUp() {
		System.out.println("Clear method executed");
	}

//	@Test
	@ParameterizedTest
//	@CsvSource({"2,3,5","60,20,80","4,5,9"})
	@CsvFileSource(resources = "data.txt")
//	@ValueSource()
	void testAdd(int n1,int n2,int expected) {
		Calculator calc=new Calculator();
		int actual=calc.add(n1, n2);
		System.out.println("Test add executed");
		assertEquals(expected,actual);
	}

	@Test
//	@Disabled
	void testSubtract() {
		Calculator calc=new Calculator();
		int actual=calc.subtract(100, 50);
		System.out.println("Test subtract executed");
		assertEquals(50, actual);
	}

}
