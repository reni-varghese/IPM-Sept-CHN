package org.reni;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class CalculatorTest2 {
	
	Calculator calc;
	
	@BeforeEach
	void init() {
		calc=new Calculator();
	}
	@Order(1)
	@Test
	@DisplayName("Testing Multiplcation")
	void testMultiply() {
		int result=calc.multiply(10, 2);
		
		assertEquals(20, result);
	}

//	@Test
	@RepeatedTest(3)
//	@Disabled
	@Order(2)
	void testDivide() {
		int result=calc.divide(10, 2);
		assertEquals(5, result);
	}
	@Test
	@Order(3)
	void testException() {
		
		assertThrows(InvalidDenominatorException.class, ()->calc.divide(10, 0));
	}

}
