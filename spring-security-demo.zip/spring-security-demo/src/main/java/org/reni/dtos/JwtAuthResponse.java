package org.reni.dtos;

import lombok.Getter;
import lombok.Setter;


public class JwtAuthResponse {
	@Getter
	@Setter
	private String accessToken;
	@Getter
	private String tokenType="Bearer";

}
