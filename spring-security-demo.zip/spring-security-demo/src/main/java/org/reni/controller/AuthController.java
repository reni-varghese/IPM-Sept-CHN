package org.reni.controller;

import org.reni.dtos.JwtAuthResponse;
import org.reni.dtos.LoginDto;
import org.reni.service.AuthService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/auth")
public class AuthController {
	
	
	private AuthService authService;
		
	public AuthController(AuthService authService) {
		super();
		this.authService = authService;
	}


	@PostMapping(value = {"/login","/signin"})
	public ResponseEntity<JwtAuthResponse> login(@RequestBody LoginDto loginDto) {
		
		String result=authService.login(loginDto);
		JwtAuthResponse response=new JwtAuthResponse();
		response.setAccessToken(result);
		return ResponseEntity.ok(response);
		
	}

}
