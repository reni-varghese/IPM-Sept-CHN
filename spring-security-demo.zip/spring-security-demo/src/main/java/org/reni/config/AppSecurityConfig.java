package org.reni.config;

import java.beans.BeanProperty;

import org.reni.security.JwtAuthenticationEntryPoint;
import org.reni.security.JwtAuthenticationFilter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import lombok.RequiredArgsConstructor;

@Configuration
@EnableMethodSecurity
@RequiredArgsConstructor
public class AppSecurityConfig {
	
	private final JwtAuthenticationEntryPoint authenticationEntryPoint;
	
	private final JwtAuthenticationFilter authenticationFilter;
	
	@Bean
	SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
		
		http.csrf(config->config.disable());
		http.authorizeHttpRequests(auth->auth.requestMatchers("/hello","/api/auth/**").permitAll()
				.anyRequest().authenticated())
		.sessionManagement(smc->smc.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
		.exceptionHandling(ehc->ehc.authenticationEntryPoint(authenticationEntryPoint))
		.addFilterBefore(authenticationFilter, UsernamePasswordAuthenticationFilter.class);
		
		
		
		
		return http.build();
		
	}
	
	@Bean
	AuthenticationManager authenticationManager(AuthenticationConfiguration config) throws Exception {
		
		return config.getAuthenticationManager();
		
	}
		
		
	
	
//	@Bean
//	UserDetailsService userDetailsService() {
//		
//		UserDetails reni=User.builder().username("reni").password(passwordEncoder().encode("pass")).roles("USER").build();
////		UserDetails reni1=User.withUsername("reni").password("pass").roles("USER").build();
//		
//		UserDetails binu=User.builder().username("binu").password(passwordEncoder().encode("pwd")).roles("ADMIN").build();
//		
//		return new InMemoryUserDetailsManager(reni,binu);
//			
//		
//	}
	@Bean
	PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}

}
