package org.reni.service;

import org.reni.dtos.LoginDto;
import org.reni.dtos.UserDto;

public interface AuthService {
	
	String login(LoginDto loginDto);
	
	String register(UserDto userDto);

}
