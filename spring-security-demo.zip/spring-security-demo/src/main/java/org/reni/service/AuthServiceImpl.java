package org.reni.service;

import org.reni.dtos.LoginDto;
import org.reni.dtos.UserDto;
import org.reni.security.JwtTokenProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
@Service
public class AuthServiceImpl implements AuthService {
	@Autowired
	private AuthenticationManager authenticationManager;
	@Autowired
	private JwtTokenProvider jwtTokenProvider;

	@Override
	public String login(LoginDto loginDto) {
		
		
		UsernamePasswordAuthenticationToken token=
				new UsernamePasswordAuthenticationToken(loginDto.getUsernameOrEmail(), loginDto.getPassword());
		
		Authentication authentication= authenticationManager.authenticate(token);
		
		SecurityContextHolder.getContext().setAuthentication(authentication);
		
		String jwt=jwtTokenProvider.generateToken(authentication);
		
		return jwt;
	}

	@Override
	public String register(UserDto userDto) {
		// TODO Auto-generated method stub
		return null;
	}

}
