package com.cts.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cts.model.Employee;
import com.cts.service.EmployeeService;

@Controller

public class EmployeeController {
	@Autowired	
	private EmployeeService employeeService;
	
	@GetMapping("/hello")
	public String sayHello() {
		
		return "hello";
	}
	@GetMapping("/")
	public ModelAndView getAll() {
		
		ModelAndView mv=new ModelAndView("index");
		List<Employee> employees=employeeService.getAll();
		mv.addObject("employees", employees);
		return mv;
	}
}
