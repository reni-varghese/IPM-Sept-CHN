package org.reni;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MultitableServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(MultitableServiceApplication.class, args);
    }

}
