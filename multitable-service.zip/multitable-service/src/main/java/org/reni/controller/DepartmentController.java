package org.reni.controller;

import org.reni.entities.Department;
import org.reni.service.DepartmentService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/departments")
public class DepartmentController {

    private DepartmentService departmentService;
    public DepartmentController(DepartmentService departmentService) {
        this.departmentService = departmentService;
    }
    @GetMapping
    public List<Department> getAllDepartments() {
        return departmentService.getAllDepartments();
    }
    @GetMapping("/{deptId}")
    public Department getDepartmentById(@PathVariable("deptId") int id) {
        return departmentService.getDepartmentById(id);
    }
    @PostMapping
    public String addDepartment(@RequestBody Department department) {
        return departmentService.addDepartment(department);
    }

    @PutMapping("/{id}")
    public String updateDepartment(@PathVariable("id") int id, @RequestBody Department department) {
        return departmentService.updateDepartment(id, department);
    }

    @DeleteMapping("/{id}")
    public String deleteDepartment(@PathVariable("id") int id) {
        return departmentService.deleteDepartment(id);
    }


}
