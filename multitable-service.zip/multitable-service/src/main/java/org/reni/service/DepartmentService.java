package org.reni.service;

import org.reni.entities.Department;

import java.util.List;

public interface DepartmentService {

    List<Department> getAllDepartments();
    Department getDepartmentById(int id);
    String addDepartment(Department department);
    String updateDepartment(int id,Department department);
    String deleteDepartment(int id);

}
