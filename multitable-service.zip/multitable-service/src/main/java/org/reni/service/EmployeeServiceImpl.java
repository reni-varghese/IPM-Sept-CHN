package org.reni.service;

import org.reni.entities.Employee;
import org.reni.exceptions.EmployeeNotFoundException;
import org.reni.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class EmployeeServiceImpl implements EmployeeService {


    private  EmployeeRepository employeeRepository;

    public EmployeeServiceImpl(EmployeeRepository employeeRepository) {
        this.employeeRepository = employeeRepository;
    }

    @Override
    public List<Employee> getEmployees() {
        return employeeRepository.findAll();
    }

    @Override
    public Employee getEmployee(int id) {
        return employeeRepository.findById(id).orElseThrow(()->new EmployeeNotFoundException("Employee with Id "+id+" not found"));
    }

    @Override
    public String addEmployee(Employee employee) {
        employeeRepository.save(employee);
        return "Employee added successfully";
    }

    @Override
    public String updateEmployee(int id, Employee employee) {

        if(employeeRepository.findById(id).isPresent()) {
            var emp= employeeRepository.findById(id).get();
            if(employee.getName()!=null) {
                emp.setName(employee.getName());
            }
            if(employee.getGender()!=null) {
                emp.setGender(employee.getGender());
            }
            if(employee.getAge()!=0){
                emp.setAge(employee.getAge());
            }
            if(employee.getSalary()!=0){
                emp.setSalary(employee.getSalary());
            }
            employeeRepository.save(emp);
            return "Employee updated successfully";
        }

        throw new EmployeeNotFoundException("Employee with Id "+id+" not found");
    }

    @Override
    public String deleteEmployee(int id) {
        employeeRepository.deleteById(id);
        return "Employee deleted successfully";
    }
}
