package org.reni.service;

import org.reni.entities.Department;
import org.reni.exceptions.DepartmentNotFoundException;
import org.reni.repository.DepartmentRepository;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class DepartmentServiceImpl implements DepartmentService {

    private DepartmentRepository departmentRepository;

    public DepartmentServiceImpl(DepartmentRepository departmentRepository) {
        this.departmentRepository = departmentRepository;
    }

    @Override
    public List<Department> getAllDepartments() {
        return departmentRepository.findAll();
    }

    @Override
    public Department getDepartmentById(int id) {

        return departmentRepository.findById(id).
                orElseThrow(()->new DepartmentNotFoundException("Department with id "+id+" not found"));

    }

    @Override
    public String addDepartment(Department department) {
        departmentRepository.save(department);
        return "Department saved successfully";
    }

    @Override
    public String updateDepartment(int id, Department department) {

        if(departmentRepository.existsById(id)) {
            Department dept=departmentRepository.findById(id).get();
            if(department.getName()!=null) {
                dept.setName(department.getName());
            }
            if(department.getLocation()!=null) {
                dept.setLocation(department.getLocation());
            }
            departmentRepository.save(dept);
            return "Department updated successfully";
        }
        throw new DepartmentNotFoundException("Department with id "+id+" not found");



    }

    @Override
    public String deleteDepartment(int id) {
        if(departmentRepository.existsById(id)) {
            departmentRepository.deleteById(id);
            return "Department deleted successfully";
        }
        throw new DepartmentNotFoundException("Department with id "+id+" not found");
    }
}
