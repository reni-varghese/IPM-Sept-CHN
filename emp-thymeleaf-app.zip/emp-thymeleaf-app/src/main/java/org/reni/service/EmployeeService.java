package org.reni.service;

import java.util.List;

import org.reni.entities.Employee;

public interface EmployeeService {

	List<Employee> getAll();

	Employee getById(int id);

	Employee addEmployee(Employee employee);

	Employee updateEmployee(Employee employee);

	void deleteEmployee(int id);

}