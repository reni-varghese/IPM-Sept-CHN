package org.reni.service;

import java.util.List;

import org.reni.entities.Employee;
import org.reni.repository.EmployeeRepository;
import org.springframework.stereotype.Service;

@Service
public class EmployeeServiceImpl implements EmployeeService {
	
	private EmployeeRepository employeeRepository;

	public EmployeeServiceImpl(EmployeeRepository employeeRepository) {
		super();
		this.employeeRepository = employeeRepository;
	}
	
	@Override
	public List<Employee> getAll(){
		
		return employeeRepository.findAll();
	}
	
	@Override
	public Employee getById(int id) {
		return employeeRepository.findById(id).get();
	}
	
	@Override
	public Employee addEmployee(Employee employee) {
		return employeeRepository.save(employee);
	}
	@Override
	public Employee updateEmployee(Employee employee) {
		return employeeRepository.save(employee);
	}
	
	@Override
	public void deleteEmployee(int id) {
		employeeRepository.deleteById(id);
	}
	

}
