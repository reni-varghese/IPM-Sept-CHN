package org.reni.entities;

import java.time.LocalDate;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name="employees")
public class Employee {

	@Id
	private int empId;
	@Pattern(regexp = "[A-Za-z\s]+")
	private String employeeName;
	private String gender;
	@Min(18)
	@Max(60)
	private int age;
	private LocalDate doj;
	private double salary;
}
