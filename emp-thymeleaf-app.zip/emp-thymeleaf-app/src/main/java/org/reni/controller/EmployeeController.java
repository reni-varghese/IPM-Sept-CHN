package org.reni.controller;

import java.beans.PropertyEditorSupport;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import org.reni.entities.Employee;
import org.reni.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import jakarta.validation.Valid;

@Controller
public class EmployeeController {
	
	private EmployeeService employeeService;

	@Autowired
	public EmployeeController(EmployeeService employeeService) {
		super();
		this.employeeService = employeeService;
	}
	@InitBinder
	public void initBinder(WebDataBinder binder) {
		
		binder.registerCustomEditor(LocalDate.class, new PropertyEditorSupport() {

			@Override
			public void setAsText(String text) throws IllegalArgumentException {
				
				setValue(LocalDate.parse(text,DateTimeFormatter.ofPattern("yyyy-MM-dd")));
			}
			
			
		});
	}
	
//	@RequestMapping(value = "/",method = RequestMethod.GET)
	@GetMapping("/")
	public String getAll(Model model) {
	
		var employees=employeeService.getAll();
		model.addAttribute("employees", employees);
		return "index";
		
	}
	@GetMapping("/add")
	public String showAddForm(Model model) {
		
		Employee employee=new Employee();
		model.addAttribute("employee",employee);
		return "add";
	}
	@PostMapping("/add-employee")
	public String addEmployee(@Valid @ModelAttribute Employee employee,BindingResult bindingResult) {
		
		if(bindingResult.hasErrors()) {
			return "add";
		}
		
		employeeService.addEmployee(employee);
		return "redirect:/";
		
	}
	@GetMapping("/edit")
	public String showUpdate(Model model,@RequestParam int id) {
		
		var employee=employeeService.getById(id);
		
		model.addAttribute("employee", employee);
		return "update";
		
		
		
	}
	@PostMapping("/update-employee")
	public String updateEmployee(@Valid @ModelAttribute Employee employee, BindingResult bindingResult) {
		
		if(bindingResult.hasErrors()) {
			return "update";
		}
		
		employeeService.updateEmployee(employee);
		return "redirect:/";
		
	}
	@GetMapping("/delete")
	public String delete(@RequestParam int id) {
		
		employeeService.deleteEmployee(id);
		return "redirect:/";
	}
	
	
	

}
