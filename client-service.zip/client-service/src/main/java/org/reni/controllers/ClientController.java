package org.reni.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.AutoConfigureOrder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestClient;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.reactive.function.client.WebClient;

@RestController
public class ClientController {
	@Autowired
	private RestTemplate restTemplate;
	@Autowired
	private RestClient restClient;
	@Autowired
	private WebClient webClient;
	
	@GetMapping("/messages")
	public String getMessages() {
		
		
//		RestTemplate restTemplate=new RestTemplate();
		
//		String first=restTemplate.getForObject("http://localhost:8081/first", String.class);
//		
//		String second=restTemplate.getForObject("http://localhost:8082/second", String.class);
		
		
//		String first=restClient.get()
//		.uri("http://localhost:8081/first")
//		.retrieve()
//		.body(String.class);
//		
//		String second=restClient.get().uri("http://localhost:8082/second").retrieve().body(String.class);
		
		String first=webClient.get().uri("http://localhost:8081/first")
		.retrieve().bodyToMono(String.class)
		.block();
		
		String second=webClient.get().uri("http://localhost:8082/second")
				.retrieve().bodyToMono(String.class)
				.block();
				
		
		String response=first+" ===== "+second;
		return response;
		
		
	}

}
