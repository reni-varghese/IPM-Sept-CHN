package org.reni.service;

import java.util.List;

import org.reni.dao.EmployeeDao;
import org.reni.model.Employee;

public class EmployeeService {

	private EmployeeDao employeeDao;
	
	public EmployeeService() {
		employeeDao=new EmployeeDao();
	}
	
	public List<Employee> getAll(){
		return employeeDao.getAll();
	}
	
	public String addEmployee(Employee employee) {
		return employeeDao.addEmployee(employee);
	}
	
	public Employee getById(int id) {
		return employeeDao.getById(id);
	}
	
	public String updateEmployee(Employee employee) {
		return employeeDao.updateEmployee(employee);
	}
	
	public String deleteEmployee(int id) {
		return employeeDao.deleteEmployee(id);
	}
	
}
