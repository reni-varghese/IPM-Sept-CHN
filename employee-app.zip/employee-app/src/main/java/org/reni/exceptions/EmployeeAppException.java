package org.reni.exceptions;

public class EmployeeAppException extends RuntimeException {

	public EmployeeAppException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public EmployeeAppException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
