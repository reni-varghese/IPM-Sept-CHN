package org.reni.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import org.reni.model.Employee;
import org.reni.service.EmployeeService;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

public class EmployeeServlet extends HttpServlet {
	
	private EmployeeService employeeService;
	
	public EmployeeServlet() {
		employeeService=new EmployeeService();
	}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	
		resp.setContentType("text/html");
		PrintWriter out=resp.getWriter();
		
		String url=req.getRequestURI();
		
		String contextRoot=req.getContextPath();
		url=url.substring(contextRoot.length());
		HttpSession session=req.getSession();
		if(url.equals("/")) {
			
			List<Employee> employees=employeeService.getAll();
			session.setAttribute("employees", employees);
//			session.removeAttribute("employees");
			resp.sendRedirect("employees.jsp");
			
			
		}
		if(url.equals("/add")) {
			
			resp.sendRedirect("add.jsp");
		}
		
		if(url.equals("/add-employee")) {
			
			int id=Integer.parseInt(req.getParameter("id"));
			String name=req.getParameter("name");
			String gender=req.getParameter("gender");
			int age=Integer.parseInt(req.getParameter("age"));
			double salary=Double.parseDouble(req.getParameter("salary"));
			Employee employee=new Employee(id, name, gender, age, salary);
			
			String result=employeeService.addEmployee(employee);
			var employees=employeeService.getAll();
			session.setAttribute("employees", employees);
			resp.sendRedirect("employees.jsp");
			
			
		}
		if(url.equals("/update")) {
			
			int id=Integer.parseInt(req.getParameter("id"));
			Employee employee=employeeService.getById(id);
			session.setAttribute("employee", employee);
			
			resp.sendRedirect("update.jsp");
		}
		
		if(url.equals("/update-employee")) {
			int id=Integer.parseInt(req.getParameter("id"));
			String name=req.getParameter("name");
			String gender=req.getParameter("gender");
			int age=Integer.parseInt(req.getParameter("age"));
			double salary=Double.parseDouble(req.getParameter("salary"));
			Employee employee=new Employee(id, name, gender, age, salary);
			String result=employeeService.updateEmployee(employee);
			var employees=employeeService.getAll();
			session.setAttribute("employees", employees);
			resp.sendRedirect("employees.jsp");
			
		}
		
		if(url.equals("/delete")) {
			int id=Integer.parseInt(req.getParameter("id"));
			String name=req.getParameter("name");
			String result=employeeService.deleteEmployee(id);
			
			var employees=employeeService.getAll();
			session.setAttribute("employees", employees);
			resp.sendRedirect("employees.jsp");
		}
		
		
		
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		doGet(req, resp);
		
	}
	
	

}
