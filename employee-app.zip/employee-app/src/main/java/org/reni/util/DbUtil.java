package org.reni.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.reni.exceptions.EmployeeAppException;

public class DbUtil {

	public static Connection getConnection() {
		Connection con=null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			String url="jdbc:mysql://localhost:3306/empdb";
			con=DriverManager.getConnection(url,"reni","password");
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			throw new EmployeeAppException(e.getMessage());
		} catch (SQLException e) {
			throw new EmployeeAppException(e.getMessage());
		}
		
		return con;
		
	}
}
