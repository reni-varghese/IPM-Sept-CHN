package org.reni.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.reni.exceptions.EmployeeAppException;
import org.reni.model.Employee;
import org.reni.util.DbUtil;

public class EmployeeDao {
	
	private Connection con=DbUtil.getConnection();
	
	
	public List<Employee> getAll(){
		
		List<Employee> employees=new ArrayList<>();
		
		try {
			Statement stat=con.createStatement();
			ResultSet rs=stat.executeQuery("SELECT * FROM employee");
			
			while(rs.next()) {
				Employee employee=new Employee();
				employee.setId(rs.getInt(1));
				employee.setName(rs.getString(2));
				employee.setGender(rs.getString(3));
				employee.setAge(rs.getInt(4));
				employee.setSalary(rs.getDouble(5));
				employees.add(employee);
			}
			
		} catch (SQLException e) {
			throw new EmployeeAppException(e.getMessage());
		}
		
		return employees;
		
		
	}
	
	public String addEmployee(Employee employee) {
		
		try {
			PreparedStatement stat=con.prepareStatement("INSERT INTO employee VALUES(?,?,?,?,?)");
			
			stat.setInt(1, employee.getId());
			stat.setString(2, employee.getName());
			stat.setString(3, employee.getGender());
			stat.setInt(4, employee.getAge());
			stat.setDouble(5, employee.getSalary());
			stat.executeUpdate();
			return "Employee with Id "+employee.getId()+" saved successfully";
			
		} catch (SQLException e) {
			throw new EmployeeAppException(e.getMessage());
		}
		
	}
	
	public Employee getById(int id) {
		
		
		try {
			PreparedStatement stat=con.prepareStatement("SELECT * FROM employee WHERE id=?");
			stat.setInt(1, id);
			ResultSet rs=stat.executeQuery();
			rs.next();
			Employee employee=new Employee();
			employee.setId(rs.getInt("id"));
			employee.setName(rs.getString("name"));
			employee.setGender(rs.getString("gender"));
			employee.setAge(rs.getInt("age"));
			employee.setSalary(rs.getDouble("salary"));
			return employee;
			
			
		} catch (SQLException e) {
			throw new EmployeeAppException(e.getMessage());
		}
		
	}
	
	public String updateEmployee(Employee employee) {
		
		try {
			PreparedStatement stat=con.prepareStatement
					("UPDATE employee SET name=?,gender=?,age=?,salary=? where id=?");
			
			stat.setString(1, employee.getName());
			stat.setString(2, employee.getGender());
			stat.setInt(3, employee.getAge());
			stat.setDouble(4, employee.getSalary());
			stat.setInt(5, employee.getId());
			stat.executeUpdate();
			return "Employee upated successfully";
			
		} catch (SQLException e) {
			throw new EmployeeAppException(e.getMessage());
		}
		
	}
	
	public String deleteEmployee(int id) {
		
		try {
			PreparedStatement stat=con.prepareStatement("DELETE FROM employee WHERE id=?");
			stat.setInt(1, id);
			stat.executeUpdate();
			return "Employee deleted successfully";
		} catch (SQLException e) {
			throw new EmployeeAppException(e.getMessage());
		}
		
	}
	

}
