package org.reni.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.reni.entities.Employee;
import org.reni.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
@SpringBootTest
class EmployeeServiceImplTest {
	
//	EmployeeRepository repository=mock(EmployeeRepository.class);
//	
//	EmployeeService service=new EmployeeServiceImpl(repository);
	@MockBean
	EmployeeRepository repository;
	@Autowired
	EmployeeService service;

	@Test
	void testGetAllEmployees() {
		when(repository.findAll()).thenReturn(List.of(new Employee(1,"Manu","Male",23,LocalDate.now(),45000),
				new Employee(2,"Suma","Female",33,LocalDate.now(),77000)));
		
		var employees=service.getAllEmployees();
		assertEquals(2, employees.size());
	}

	@Test
	
	void testGetById() {
		when(repository.findById(anyInt())).thenReturn(Optional.of(new Employee(1,"Manu","Male",23,LocalDate.now(),45000)));
		
		Employee e=service.getById(2);
		
		assertEquals("Manu", e.getName());
		 
	}

	@Test
	@Disabled
	void testAddEmployee() {
		fail("Not yet implemented");
	}

	@Test
	@Disabled
	void testUpdateEmployee() {
		fail("Not yet implemented");
	}

	@Test
	@Disabled
	void testDeleteEmployee() {
		fail("Not yet implemented");
	}

}
