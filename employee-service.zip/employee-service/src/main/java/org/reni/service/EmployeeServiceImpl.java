package org.reni.service;

import java.util.List;
import java.util.Optional;

import org.reni.entities.Employee;
import org.reni.exceptions.EmployeeNotFoundException;
import org.reni.repository.EmployeeRepository;
import org.springframework.stereotype.Service;
@Service
public class EmployeeServiceImpl implements EmployeeService {
	
	private EmployeeRepository employeeRepository;
	
	public EmployeeServiceImpl(EmployeeRepository employeeRepository) {
		super();
		this.employeeRepository = employeeRepository;
	}

	@Override
	public List<Employee> getAllEmployees() {
		// TODO Auto-generated method stub
		return employeeRepository.findAll();
	}

	@Override
	public Employee getById(int id) {
		
		return employeeRepository.findById(id)
				.orElseThrow(()->new EmployeeNotFoundException("Employee with Id "+id+" does not exist"));
	}

	@Override
	public Employee addEmployee(Employee employee) {
		// TODO Auto-generated method stub
		return employeeRepository.save(employee);
	}

	@Override
	public Employee updateEmployee(int id, Employee employee) {
		
		Optional<Employee> byId = employeeRepository.findById(id);
		if(!byId.isPresent()) {
			throw new EmployeeNotFoundException("Employee with Id "+id+" does not exist");
		}
//		if(byId.isEmpty()) {
//			
//		}
		
		Employee emp=byId.get();
		if(employee.getName()!=null) {
			emp.setName(employee.getName());
		}
		if(employee.getGender()!=null) {
			emp.setGender(employee.getGender());
		}
		if(employee.getAge()!=0) {
			emp.setAge(employee.getAge());
		}
		if(employee.getDoj()!=null) {
			emp.setDoj(employee.getDoj());
		}
		if(employee.getSalary()!=0) {
			emp.setSalary(employee.getSalary());
		}
		
		return employeeRepository.save(emp);
		
		// TODO Auto-generated method stub
		
	}

	@Override
	public String deleteEmployee(int id) {
		Optional<Employee> optEmp=employeeRepository.findById(id);
		if(optEmp.isEmpty()) {
			throw new EmployeeNotFoundException("Employee with Id "+id+" does not exist");
		}
		employeeRepository.deleteById(id);
		return "Employee with Id "+id+" deleted successfully";
	}

}
