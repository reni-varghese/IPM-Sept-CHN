package org.reni.entities;

import java.time.LocalDate;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name="employees")
public class Employee {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	

	@Pattern(regexp = "[A-Za-z\s]+")
	private String name;
	@Pattern(regexp = "(Male|Female)",message = "Gender can be only either Male or Female")
	private String gender;
	@Max(60)
	@Min(value = 18, message = "Age should be alway above 18")
	private int age;
	private LocalDate doj;
	private double salary;

}
