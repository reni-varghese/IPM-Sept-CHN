package org.reni.controller;

import java.util.List;

import org.reni.entities.Employee;
import org.reni.service.EmployeeService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import jakarta.validation.Valid;
import lombok.val;

@RestController
@RequestMapping("/api/employees")
public class EmployeeController {
	
	private EmployeeService employeeService;

	public EmployeeController(EmployeeService employeeService) {
		super();
		this.employeeService = employeeService;
	}
	@GetMapping
	public List<Employee> getAll(){
		return employeeService.getAllEmployees();
	}
	@PostMapping
	public ResponseEntity<Employee> addEmployee(@Valid @RequestBody Employee employee) {
		
		var emp=employeeService.addEmployee(employee);
//		return new ResponseEntity<Employee>(emp,HttpStatus.CREATED);
		return ResponseEntity.status(HttpStatus.CREATED).body(emp);
		
	}
	@GetMapping("/{id}")
	public Employee getEmployeeById(@PathVariable int id) {
		
		return employeeService.getById(id);
	}
	@PutMapping("/{id}")
	public Employee update(@PathVariable int id,@Valid @RequestBody Employee employee) {
		
		return employeeService.updateEmployee(id, employee);
	}
	@DeleteMapping("/{id}")
	public String delete(@PathVariable int id) {
		
		return employeeService.deleteEmployee(id);
	}

}
