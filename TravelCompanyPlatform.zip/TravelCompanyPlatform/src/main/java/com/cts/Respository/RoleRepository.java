package com.cts.Respository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.model.Role;

// Repository interface for Role entity
public interface RoleRepository extends JpaRepository<Role, Integer> {

    // Method to find a role by its name
    Optional<Role> findByName(String name);
}
