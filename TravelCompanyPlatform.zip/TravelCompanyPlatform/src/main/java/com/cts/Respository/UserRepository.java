package com.cts.Respository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.model.User;

// Repository interface for User entity
public interface UserRepository extends JpaRepository<User, Integer> {

    // Method to find a user by username
    Optional<User> findByUsername(String username);

    // Method to find a user by email
    Optional<User> findByEmail(String email);

    // Method to find a user by either username or email
    Optional<User> findByUsernameOrEmail(String username, String email);
}
