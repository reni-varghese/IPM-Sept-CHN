package com.cts.Respository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.model.Weather;

//Repository class communicates with the database
public interface TravelRepository extends JpaRepository<Weather,Integer> {

}
