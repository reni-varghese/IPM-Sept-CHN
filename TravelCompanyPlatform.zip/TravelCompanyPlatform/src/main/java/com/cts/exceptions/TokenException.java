package com.cts.exceptions;

import org.springframework.http.HttpStatus;

// Custom exception for handling token-related errors
public class TokenException extends RuntimeException {

    // Constructor to initialize the exception with status and message
    public TokenException(HttpStatus status, String message) {
        super(message);
    }
}
