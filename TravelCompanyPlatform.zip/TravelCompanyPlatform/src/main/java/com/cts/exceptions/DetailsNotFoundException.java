package com.cts.exceptions;

// Custom exception for handling cases where details are not found
public class DetailsNotFoundException extends RuntimeException {
    
    // Exception message
    String message;

    // Constructor to initialize the exception with a message
    public DetailsNotFoundException(String message) {
        super();
        this.message = message;
    }
}
