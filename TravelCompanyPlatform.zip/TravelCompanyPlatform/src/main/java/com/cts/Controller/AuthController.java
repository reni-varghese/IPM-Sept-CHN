package com.cts.Controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.Service.AuthService;
import com.cts.dtos.JwtAuthResponse;
import com.cts.dtos.LoginDto;

// Rest Controller for authentication-related endpoints
@RestController

public class AuthController {
	
	
	private AuthService authService;
	
	// Constructor Injection for AuthService
	public AuthController(AuthService authService) {
		super();
		this.authService = authService;
	}

	// Processes login/signin requests
	@PostMapping(value = {"/login","/signin"})
	public ResponseEntity<JwtAuthResponse> login(@RequestBody LoginDto loginDto) {
		
		String result=authService.login(loginDto);
		JwtAuthResponse response=new JwtAuthResponse();
		response.setAccessToken(result);
		return ResponseEntity.ok(response);
		
	}

}
