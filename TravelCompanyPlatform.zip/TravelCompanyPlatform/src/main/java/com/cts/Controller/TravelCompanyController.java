package com.cts.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.Service.TravelService;
import com.cts.model.Weather;


@RestController //Rest Controller for managing weather details.
//It combines the functionality of @Controller and @ResponseBody
@RequestMapping("/weatherDetails") 
public class TravelCompanyController {
	TravelService ts;
	
	// Constructor injection for TravelService
	public TravelCompanyController(TravelService ts) {
		super();
		this.ts = ts;
	}
	
	// Adds new weather details
	@PostMapping("/addWeatherDetails")
	public ResponseEntity<Weather> addDetail(@RequestBody Weather travelCompany){
		Weather message=ts.addDetail(travelCompany);
		return new ResponseEntity<Weather>(message, HttpStatus.CREATED);
	}
	
	// Retrieves all weather details
	@GetMapping
	public List<Weather> getAll(){
		return ts.getDetails();
	}
	
	// Updates existing weather details by ID
	@PutMapping("/update/{id}")
	public ResponseEntity<Weather> updateDetail(@PathVariable int id,@RequestBody Weather weather) {
		Weather message = ts.updateDetail(id, weather);
		return new ResponseEntity<Weather>(message, HttpStatus.OK);
		
	}
	
	// Deletes weather details by ID
	@DeleteMapping("/delete/{id}")
	public ResponseEntity<String> deleteDetail(@PathVariable int id) {
	    ts.deleteDetail(id);
	    return ResponseEntity.noContent().header("Message", "Record deleted successfully").build();
	}

	// Retrieves weather details by ID
	@GetMapping("/{id}")
	public ResponseEntity<Weather> getById(@PathVariable int id) {
		Weather weather= ts.getById(id);
		return new ResponseEntity<Weather>(weather,HttpStatus.OK);
	}
}
