package com.cts.Controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.cts.exceptions.DetailsNotFoundException;

// Controller advice is a annotation to handle exceptions globally
@ControllerAdvice
public class ErrorHandler {

    // Handle DetailsNotFoundException
    @ExceptionHandler(DetailsNotFoundException.class)
    public ResponseEntity<String> handleEmployeeNotFound(DetailsNotFoundException ex) {
        String message = ex.getMessage(); // Get exception message
        System.out.print(message); // Print message to console
        return new ResponseEntity<>(message, HttpStatus.NOT_FOUND); // Return response with NOT_FOUND status
    }

    // Handle validation errors
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<String> handleValidationErrors(MethodArgumentNotValidException ex) {
        List<ObjectError> errors = ex.getAllErrors(); // Get all validation errors
        String message = "";
        for (ObjectError objectError : errors) {
            message += objectError.getDefaultMessage() + "\n"; // Append each error message
        }
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(message); // Return response with BAD_REQUEST status
    }
}
