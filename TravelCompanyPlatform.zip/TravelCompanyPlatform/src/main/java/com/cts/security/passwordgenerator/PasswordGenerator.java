package com.cts.security.passwordgenerator;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

public class PasswordGenerator {

	public static void main(String[] args) {
		
		
	 PasswordEncoder bCryptPasswordEncoder = new BCryptPasswordEncoder();
	
	 System.out.println(bCryptPasswordEncoder.encode("indhu01"));
	}
}
