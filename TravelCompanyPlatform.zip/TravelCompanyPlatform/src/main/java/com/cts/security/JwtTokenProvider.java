package com.cts.security;

import java.security.Key;
import java.util.Date;

import javax.crypto.SecretKey;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Component;

import com.cts.exceptions.TokenException;

import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.MalformedJwtException;
import io.jsonwebtoken.UnsupportedJwtException;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;

// Component for JWT token operations
@Component
public class JwtTokenProvider {

    @Value("${app.jwt.secret}")
    private String jwtSecret;

    @Value("${app.jwt.expiry-millis}")
    private long expiryMillis;

    // Generate JWT token
    public String generateToken(Authentication authentication) {
        String username = authentication.getName(); // Get the username of the authenticated user

        Date curDate = new Date();
        Date expiryDate = new Date(curDate.getTime() + expiryMillis);
        String token = Jwts.builder()
                .subject(username)
                .issuedAt(new Date())
                .expiration(expiryDate)
                .signWith(generateKey())
                .compact(); // Build the token

        return token;
    }

    // Generate the signing key
    private Key generateKey() {
        return Keys.hmacShaKeyFor(Decoders.BASE64.decode(jwtSecret));
    }

    // Extract username from JWT token
    public String getUsernameFromToken(String token) {
        String username = Jwts.parser().verifyWith((SecretKey) generateKey())
                .build().parseSignedClaims(token)
                .getPayload().getSubject();
        return username;
    }

    // Validate JWT token
    public boolean validateToken(String token) {
        try {
            Jwts.parser().verifyWith((SecretKey) generateKey())
                    .build()
                    .parse(token);
           
        } catch (MalformedJwtException ex) {
            throw new TokenException(HttpStatus.BAD_REQUEST, "Invalid token");
        } catch (ExpiredJwtException ex) {
            throw new TokenException(HttpStatus.BAD_REQUEST, "Token Expired");
        } catch (UnsupportedJwtException ex) {
            throw new TokenException(HttpStatus.BAD_REQUEST, "Unsupported Token");
        } catch (IllegalArgumentException ex) {
            throw new TokenException(HttpStatus.BAD_REQUEST, "Token claims are empty");
        }
        return true;
    }
}
