package com.cts.Service;

import java.util.List;
import java.util.Optional;

import com.cts.model.Weather;

// Service interface for managing travel-related operations
public interface TravelService {

    // Method to get all weather details
    List<Weather> getDetails();

    // Method to add new weather details
    Weather addDetail(Weather travel);

    // Method to update existing weather details by ID
    Weather updateDetail(int id, Weather travel);

    // Method to delete weather details by ID
    Optional<Weather> deleteDetail(int id);

    // Method to get weather details by ID
    Weather getById(int id);
}
