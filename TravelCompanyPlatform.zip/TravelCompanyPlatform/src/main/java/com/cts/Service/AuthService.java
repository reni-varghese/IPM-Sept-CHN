package com.cts.Service;

import com.cts.dtos.LoginDto;
import com.cts.dtos.UserDto;

// Service interface for authentication operations
public interface AuthService {

    // Method to handle user login
    String login(LoginDto loginDto);

    // Method to handle user registration
    String register(UserDto userDto);
}
