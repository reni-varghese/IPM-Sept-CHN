package com.cts.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import com.cts.Respository.TravelRepository;
import com.cts.exceptions.DetailsNotFoundException;
import com.cts.model.Weather;

@Service
public class TravelServiceImplementation implements TravelService {

    private final TravelRepository tr;

    // Constructor to initialize the TravelRepository
    public TravelServiceImplementation(TravelRepository tr) {
        super();
        this.tr = tr;
    }

    // Method to get all weather details
    @Override
    public List<Weather> getDetails() {
        return tr.findAll();
    }

    // Method to add new weather details
    @Override
    public Weather addDetail(Weather travel) {
        return tr.save(travel);
    }

    // Method to update existing weather details by ID
    @Override
    public Weather updateDetail(int id, Weather travel) {
        Optional<Weather> a = tr.findById(id);
        if (!a.isPresent()) {
            System.out.println("Hetheesh");
        }
        Weather td = a.get();

        if (travel.getDate() != null) {
            td.setDate(travel.getDate());
        }
        if (travel.getLat() != 0.0) {
            td.setLat(travel.getLat());
        }
        if (travel.getLon() != 0.0) {
            td.setLon(travel.getLon());
        }
        if (travel.getCity() != null) {
            td.setCity(travel.getCity());
        }
        if (travel.getState() != null) {
            td.setState(travel.getState());
        }
        if (travel.getTemp() != 0.0) {
            td.setTemp(travel.getTemp());
        }
        return tr.save(td);
    }

    // Method to delete weather details by ID
    @Override
    public Optional<Weather> deleteDetail(int id) {
        Optional<Weather> weather = tr.findById(id);
        if (weather.isEmpty()) {
            return Optional.empty();
        }
        return weather;
    }

    // Method to get weather details by ID
    @Override
    public Weather getById(int id) {
        return tr.findById(id).orElseThrow(() -> new DetailsNotFoundException("Details not found"));
    }
}
