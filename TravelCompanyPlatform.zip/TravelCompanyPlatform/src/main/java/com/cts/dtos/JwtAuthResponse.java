package com.cts.dtos;

import lombok.Getter;
import lombok.Setter;

// DTO for JWT authentication response
public class JwtAuthResponse {
    
    // Access token for authentication
    @Getter
    @Setter
    private String accessToken;
    
    @Override
	public String toString() {
		return "JwtAuthResponse [accessToken=" + accessToken + ", tokenType=" + tokenType + "]";
	}

	public JwtAuthResponse() {
		super();
		// TODO Auto-generated constructor stub
	}

	public JwtAuthResponse(String accessToken, String tokenType) {
		super();
		this.accessToken = accessToken;
		this.tokenType = tokenType;
	}

	public String getTokenType() {
		return tokenType;
	}

	public void setTokenType(String tokenType) {
		this.tokenType = tokenType;
	}

	public String getAccessToken() {
		return accessToken;
	}

	// Token type, default is "Bearer"
    @Getter
    private String tokenType = "Bearer";

	public void setAccessToken(String result) {
		// TODO Auto-generated method stub
		
	}
}
