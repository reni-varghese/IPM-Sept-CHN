package com.cts.dtos;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;



@AllArgsConstructor // Lombok annotation to generate all-args constructor

@NoArgsConstructor // Lombok annotation to generate no-args constructor
@Data
public class LoginDto {

    // User's username or email
    private String usernameOrEmail;
    private String password;
//    private String password;
    @Override
	public String toString() {
		return "LoginDto [usernameOrEmail=" + usernameOrEmail + ", password=" + password + "]";
	}
	public String getUsernameOrEmail() {
		return usernameOrEmail;
	}
	public LoginDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	public LoginDto(String usernameOrEmail, String password) {
		super();
		this.usernameOrEmail = usernameOrEmail;
		this.password = password;
	}
	public void setUsernameOrEmail(String usernameOrEmail) {
		this.usernameOrEmail = usernameOrEmail;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	// User's password
    
}
