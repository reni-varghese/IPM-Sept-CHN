package com.cts.model;

import java.time.LocalDate;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


//To create table in database named "Weather"
@Entity 
public class Weather {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int travelId;
	private String city;
	private LocalDate date;
	private double lat;
	
	private double lon;
	
	private String state;
	private double temp;
	public int getTravelId() {
		return travelId;
	}
	public void setTravelId(int travelId) {
		this.travelId = travelId;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}
	public double getLat() {
		return lat;
	}
	public void setLat(double lat) {
		this.lat = lat;
	}
	public double getLon() {
		return lon;
	}
	public void setLon(double lon) {
		this.lon = lon;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public double getTemp() {
		return temp;
	}
	public void setTemp(double temp) {
		this.temp = temp;
	}
	public Weather(int travelId, String city, LocalDate date, double lat, double lon, String state, double temp) {
		super();
		this.travelId = travelId;
		this.city = city;
		this.date = date;
		this.lat = lat;
		this.lon = lon;
		this.state = state;
		this.temp = temp;
	}
	public Weather() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Weather [travelId=" + travelId + ", city=" + city + ", date=" + date + ", lat=" + lat + ", lon=" + lon
				+ ", state=" + state + ", temp=" + temp + "]";
	}
	
	

}
