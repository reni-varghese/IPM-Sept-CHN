package com.cts;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

//Main application class for the Travel Company Platform

@SpringBootApplication
public class TravelCompanyPlatformApplication {

	public static void main(String[] args) {
		SpringApplication.run(TravelCompanyPlatformApplication.class, args);
	}

}
