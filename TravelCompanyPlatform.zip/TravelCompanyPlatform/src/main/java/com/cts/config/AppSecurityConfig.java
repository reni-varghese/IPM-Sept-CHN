package com.cts.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import com.cts.security.JwtAuthenticationEntryPoint;
import com.cts.security.JwtAuthenticationFilter;

import lombok.RequiredArgsConstructor;

// Configuration class for Spring Security
@Configuration
@EnableMethodSecurity
@RequiredArgsConstructor
public class AppSecurityConfig {

    private final JwtAuthenticationEntryPoint authenticationEntryPoint = new JwtAuthenticationEntryPoint();
    private final JwtAuthenticationFilter authenticationFilter = new JwtAuthenticationFilter();

    // Configure the security filter chain
    @Bean
    SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http.csrf(config -> config.disable()); // Disable CSRF protection
        http.authorizeHttpRequests(auth -> auth.requestMatchers("/login").permitAll()
                .anyRequest().authenticated()) // Configure URL authorization
            .sessionManagement(smc -> smc.sessionCreationPolicy(SessionCreationPolicy.STATELESS)) // Set session management to stateless
            .exceptionHandling(ehc -> ehc.authenticationEntryPoint(authenticationEntryPoint)) // Handle authentication exceptions
            .addFilterBefore(authenticationFilter, UsernamePasswordAuthenticationFilter.class); // Add JWT filter before username/password filter

        return http.build(); // Build the security filter chain
    }

    //  Provides the authentication manager bean which manages authentication for user login 
    @Bean
    AuthenticationManager authenticationManager(AuthenticationConfiguration config) throws Exception {
        return config.getAuthenticationManager(); 
        
        // Return the authentication manager
    }

    // Provides the password encoder bean
    @Bean
    PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder(); // Return BCrypt password encoder
    }
}
