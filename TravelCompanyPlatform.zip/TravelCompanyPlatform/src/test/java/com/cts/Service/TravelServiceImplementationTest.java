package com.cts.Service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.cts.Respository.TravelRepository;
import com.cts.Service.TravelService;
import com.cts.model.Weather;

@SpringBootTest
class TravelServiceImplementationTest {
    
    @Mock
    TravelRepository travelRepository;
    //TravelRepository travelRepository= mock(TravelRepository.class);
    @Autowired
    TravelService service;
    
    //TravelService service= new TravelServiceImplementation(travelRepository);
    
    @Test
    void testGetDetails() {
        // Mocking the findAll method to return a list of Weather objects
        when(travelRepository.findAll()).thenReturn(List.of(
            new Weather(1, "Nashville", LocalDate.of(1985, 1, 1), 36.1189, 86.6892, "Tennessee", 22),
            new Weather(2, "Chennai", LocalDate.of(1985, 1, 1), 77.6875, 90.3422, "TamilNadu", 27)
        ));
        
        // Calling the service method and asserting the result
        var details = service.getDetails();
        assertEquals(2, details.size());
    }

//    @Test
//    void testAddDetail() {
//        // Creating a Weather object to add
//        Weather toAdd = new Weather(1, "Nashville", LocalDate.of(1985, 1, 1), 36.1189, 86.6892, "Tennessee", 22);
//        
//        // Mocking the save method to return the same Weather object
//        when(travelRepository.save(any(Weather.class))).thenReturn(toAdd);
//        
//        // Calling the service method and asserting the result
//        Weather weather = service.addDetail(toAdd);
//        assertEquals(toAdd.getCity(), weather.getCity());
//    }
//
//    @Test
//    void testUpdateDetail() {
//        // Creating a Weather object to update
//        Weather toAdd = new Weather(1, "Nashville", LocalDate.of(1985, 1, 1), 36.1189, 86.6892, "Tennessee", 22);
//        
//        // Mocking the save method to return the same Weather object
//        when(travelRepository.save(any(Weather.class))).thenReturn(toAdd);
//        
//        // Calling the service method and asserting the result
//        Weather weather = service.updateDetail(1, toAdd);
//        assertEquals("Nashville", weather.getCity());
//    }
//
//    @Test
//    @Disabled
//    void testDeleteDetail() {
//        // Creating a Weather object to delete
//        Weather weather = new Weather(1, "Nashville", LocalDate.of(1985, 1, 1), 36.1189, 86.6892, "Tennessee", 22);
//        
//        // Mocking the findById method to return an Optional of the Weather object
//        when(travelRepository.findById(anyInt())).thenReturn(Optional.of(weather));
//        
//        // Mocking the deleteById method to do nothing
//        doNothing().when(travelRepository).deleteById(anyInt());
//        
//        // Calling the service method and asserting the result
//        Optional<Weather> we = service.deleteDetail(1);
//        assertEquals(weather, we);
//        
//        // Verifying that the deleteById method was called
//        verify(travelRepository).deleteById(1);
//    }
//
//    @Test
//    void testGetById() {
//        // Mocking the findById method to return an Optional of a Weather object
//        when(travelRepository.findById(anyInt())).thenReturn(Optional.of(
//            new Weather(1, "Nashville", LocalDate.of(1985, 1, 1), 36.1189, 86.6892, "Tennessee", 22)
//        ));
//        
//        // Calling the service method and asserting the result
//        Weather weather = service.getById(1);
//        assertEquals("Nashville", weather.getCity());
//    }
}
