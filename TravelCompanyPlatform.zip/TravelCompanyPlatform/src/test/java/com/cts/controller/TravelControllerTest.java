package com.cts.controller;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.cts.Controller.TravelCompanyController;
import com.cts.Service.TravelService;
import com.cts.model.Weather;

public class TravelControllerTest {

    private TravelService travelService;
    private TravelCompanyController travelController;

    // Set up mock TravelService and TravelCompanyController before each test
    @BeforeEach
    public void setUp() {
        travelService = mock(TravelService.class);
        travelController = new TravelCompanyController(travelService);
    }

    // Test for getting all weather details
    @Test
    public void testGetAllWeather() {
        List<Weather> weatherDetails = Arrays.asList(
            new Weather(1, "Nashville", LocalDate.of(1985, 1, 1), 36.1189, 86.6892, "Tennessee", 22),
            new Weather(2, "Chennai", LocalDate.of(1985, 1, 1), 77.6875, 90.3422, "TamilNadu", 27)
        );
        when(travelService.getDetails()).thenReturn(weatherDetails);

        List<Weather> response = travelController.getAll();

        assertEquals(response, weatherDetails);
    }

    // Test for adding weather details
    @Test
    public void testAddWeatherDetail() {
        Weather weather = new Weather(2, "Chennai", LocalDate.of(1985, 1, 1), 77.6875, 90.3422, "TamilNadu", 27);
        when(travelService.addDetail(weather)).thenReturn(weather);

        ResponseEntity<Weather> response = travelController.addDetail(weather);
        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertEquals(weather, response.getBody());
    }

    // Test for getting weather details by ID
    @Test
    public void testGetWeatherById() {
        Weather weather = new Weather(2, "Chennai", LocalDate.of(1985, 1, 1), 77.6875, 90.3422, "TamilNadu", 27.0);
        when(travelService.getById(1)).thenReturn(weather);

        ResponseEntity<Weather> response = travelController.getById(1);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(weather, response.getBody());
    }

    // Test for updating weather details
    @Test
    public void testUpdateWeatherDetail() {
        Weather weather = new Weather(2, "Chennai", LocalDate.of(1985, 1, 1), 77.6875, 90.3422, "TamilNadu", 27);
        when(travelService.updateDetail(1, weather)).thenReturn(weather);

        ResponseEntity<Weather> response = travelController.updateDetail(1, weather);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(weather, response.getBody());
    }

    // Test for deleting weather details
    @Test
    public void testDeleteWeatherDetail() {
        when(travelService.deleteDetail(1)).thenReturn(Optional.of(new Weather(1, "Nashville", LocalDate.of(1985, 1, 1), 36.1189, 86.6892, "Tennessee", 22)));

        ResponseEntity<String> response = travelController.deleteDetail(1);
        assertEquals(HttpStatus.NO_CONTENT, response.getStatusCode());
       
    }

    // Test for getting weather details by ID when not found
    @Test
    public void testGetBookById_NotFound() {
        when(travelService.getById(1)).thenReturn(null);

        ResponseEntity<Weather> response = travelController.getById(1);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNull(response.getBody());
    }

    // Test for deleting weather details when not found
    @Test
    public void testDeleteDetail_NotFound() {
        when(travelService.deleteDetail(1)).thenReturn(null);

        ResponseEntity<String> response = travelController.deleteDetail(1);
        assertEquals(HttpStatus.NO_CONTENT, response.getStatusCode());
        
    }
}
