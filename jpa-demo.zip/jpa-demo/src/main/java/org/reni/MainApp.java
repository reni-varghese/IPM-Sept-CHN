package org.reni;

import java.beans.PersistenceDelegate;

import org.reni.entity.Address;
import org.reni.entity.User;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

public class MainApp {

	public static void main(String[] args) {
		
		EntityManagerFactory factory=
				Persistence.createEntityManagerFactory("JPA-PU");
		
		EntityManager em=
				factory.createEntityManager();
		
		Address add=new Address();
		add.setStreet("Navalur");
		add.setCity("Chennai");
		add.setPincode("560076");
		add.setState("TamilNadu");
		
		User user=new User();
		user.setName("Sunil");
		user.setAddress(add);
		add.setUser(user);
		
		em.getTransaction().begin();
		em.persist(user);
		em.persist(add);
		
		em.getTransaction().commit();
		
		System.out.println("Done");
		
//		User user=em.find(User.class, 2);
//		System.out.println(user.getName());
//		
//		System.out.println(user.getAddress().getState());
		

	}

}
