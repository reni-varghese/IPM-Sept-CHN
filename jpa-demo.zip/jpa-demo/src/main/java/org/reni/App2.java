package org.reni;

import org.reni.entity.Course;
import org.reni.entity.Student;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

public class App2 {

	public static void main(String[] args) {
		EntityManagerFactory factory=
				Persistence.createEntityManagerFactory("JPA-PU");
		
		EntityManager em=
				factory.createEntityManager();
		
		Student std=new Student();
		std.setName("Harish");
		
		Course c1=new Course();
		c1.setTitle("Java");
		Course c2=new Course();
		c2.setTitle("Spring BOOT");
		
		std.getCourses().add(c1);
		std.getCourses().add(c2);
		c1.getStudents().add(std);
		c2.getStudents().add(std);
		
		em.getTransaction().begin();
		em.persist(std);
		em.getTransaction().commit();
		
		

	}

}
