package org.reni;

import org.reni.entity.Department;
import org.reni.entity.Employee;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

public class App1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EntityManagerFactory factory=
				Persistence.createEntityManagerFactory("JPA-PU");
		
		EntityManager em=
				factory.createEntityManager();
		
		Department dept=new Department();
		dept.setName("IT");
		Employee emp=new Employee();
		emp.setName("Shivani");
		emp.setSalary(56000);
		emp.setDepartment(dept);
		Employee emp1=new Employee();
		emp1.setName("Sunil");
		emp1.setSalary(98000);
		emp1.setDepartment(dept);
		em.getTransaction().begin();
		em.persist(emp);
		em.persist(emp1);
		dept.getEmployees().add(emp);
		dept.getEmployees().add(emp1);
		em.getTransaction().commit();
		
	}

}
