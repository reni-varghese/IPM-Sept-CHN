package org.reni;

import java.time.LocalDate;
import java.util.List;

import org.reni.entity.Employee;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.TypedQuery;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
        EntityManager em = factory.createEntityManager();
//        Employee employee=new Employee(102, "Tom", "Male", 44,39000, LocalDate.of(2022,10,10));
//        em.getTransaction().begin();
//        em.persist(employee);
//        em.getTransaction().commit();
//        System.out.println("Employee Saved");
//        
//        Employee emp=em.find(Employee.class, 101);
//        System.out.println(emp);
//        em.getTransaction().begin();
//        emp.setSalary(88000);
//        em.getTransaction().commit();
//        
//        Employee e=em.find(Employee.class, 100);
//        System.out.println(e);
//        em.getTransaction().begin();
//        em.remove(e);
//        em.getTransaction().commit();
//        
//          TypedQuery<Employee> query=em.createQuery("from Employee",Employee.class);
//          List<Employee> employees=query.getResultList();
//          
//          for (Employee employee : employees) {
//			System.out.println(employee);
//		}
        
        Employee e=em.find(Employee.class, 101);
        e.setSalary(100000);
//        e.setAge(25);
        em.getTransaction().begin();
        em.merge(e);
        em.getTransaction().commit();
        
        em.close();
        factory.close();
    }
}
