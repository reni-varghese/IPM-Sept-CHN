package org.reni;

import java.time.LocalDate;

import org.reni.entity.Employee;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

public class Main {

	public static void main(String[] args) {
		
		EntityManagerFactory emf=
				Persistence.createEntityManagerFactory("JPA-PU");
		
		EntityManager em=
				emf.createEntityManager();
		
		Employee employee=new Employee();
		employee.setName("Arun");
//		employee.setGender("Male");
//		employee.setAge(22);
//		employee.setSalary(45000);
//		employee.setDoj(LocalDate.now());
		
		em.getTransaction().begin();
		em.persist(employee);
		em.getTransaction().commit();
		
		
		em.close();
		emf.close();
		

	}

}
